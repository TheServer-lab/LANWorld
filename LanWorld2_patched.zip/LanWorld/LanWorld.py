#!/usr/bin/env python3
"""
LanWorld - Complete LAN Ecosystem
Main entry point
"""

import socket
import threading
from pathlib import Path

# Third-party imports
from fastapi import FastAPI, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import uvicorn

# Local imports
from config import CONFIG
from discovery import LanDiscovery
import auth
import messenger
import social
import fileshare
import forms
import textdump
import groups
import routes

def open_browser():
    import webbrowser
    import time
    time.sleep(2)
    webbrowser.open(f"http://localhost:{CONFIG['port']}")

def main():
    print("""
    ╔══════════════════════════════════════════════════╗
    ║           LanWorld 2.0 - Expanded Edition        ║
    ║   Complete LAN Ecosystem with New Apps           ║
    ║   100% Local - Zero Cloud                        ║
    ╚══════════════════════════════════════════════════╝
    """)
    
    # Start LAN discovery
    discovery = LanDiscovery(CONFIG["discovery_port"])
    discovery.start()
    print(f"🔍 LAN Discovery started on port {CONFIG['discovery_port']}")
    
    # Create upload directory
    upload_dir = Path(CONFIG["upload_dir"])
    upload_dir.mkdir(exist_ok=True, parents=True)
    print(f"📁 Upload directory: {upload_dir.absolute()}")
    
    # Check for frontend directory
    base_dir = Path(__file__).parent
    frontend_dir = base_dir / "frontend"
    if not frontend_dir.exists():
        print(f"⚠️  Warning: Frontend directory not found at {frontend_dir.absolute()}")
        print("   Creating basic frontend structure...")
        create_basic_frontend(frontend_dir)
    
    # Create FastAPI app
    app = FastAPI(title="LanWorld", version="2.0")
    
    # CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Include routers
    app.include_router(auth.router, prefix="/api/auth", tags=["Authentication"])
    app.include_router(messenger.router, prefix="/api", tags=["Messenger"])
    app.include_router(social.router, prefix="/api", tags=["Social"])
    app.include_router(fileshare.router, prefix="/api", tags=["Fileshare"])
    app.include_router(forms.router, prefix="/api", tags=["Forms"])
    app.include_router(textdump.router, prefix="/api", tags=["TextDump"])
    app.include_router(groups.router, prefix="/api", tags=["Groups"])
    app.include_router(routes.router, tags=["Routes"])
    
    # Mount static files from the frontend directory in the base directory
    if frontend_dir.exists():
        print(f"📁 Serving static files from: {frontend_dir.absolute()}")
        app.mount("/frontend", StaticFiles(directory=str(frontend_dir)), name="frontend")
    else:
        print("❌ Frontend directory still not found after creation attempt!")
    
    # Register WebSocket endpoints
    @app.websocket("/api/ws")
    async def websocket_endpoint(websocket: WebSocket, token: str):
        await messenger.websocket_endpoint(websocket, token)
    
    @app.websocket("/api/ws/group/{group_id}")
    async def group_websocket_endpoint(websocket: WebSocket, group_id: str, token: str):
        await groups.group_websocket_endpoint(websocket, group_id, token)
    
    # Open browser
    threading.Thread(target=open_browser, daemon=True).start()
    
    # Get IP addresses
    try:
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        ips = [local_ip]
    except:
        ips = []
    
    print(f"\n🌐 Server starting...")
    print(f"📡 Local URLs:")
    print(f"   http://localhost:{CONFIG['port']}")
    print(f"   http://127.0.0.1:{CONFIG['port']}")
    for ip in ips:
        if ip not in ['127.0.0.1', 'localhost']:
            print(f"   http://{ip}:{CONFIG['port']}")
    
    print(f"\n💡 Other users on your LAN can connect via:")
    print(f"   http://<YOUR-IP>:{CONFIG['port']}")
    print(f"\n📱 New Apps Available:")
    print(f"   📝 Reddit-like Forms")
    print(f"   📋 Pastebin-style Text Dump")
    print(f"   👥 Discord-like Group Chats")
    print(f"   💬 Working Likes & Comments")
    print(f"\n🚀 Press Ctrl+C to stop the server\n")
    
    # Start server
    uvicorn.run(
        app, 
        host=CONFIG["host"], 
        port=CONFIG["port"], 
        log_level="info",
        ws_ping_interval=20,
        ws_ping_timeout=20
    )

def create_basic_frontend(frontend_dir):
    """Create a basic frontend structure if it doesn't exist"""
    try:
        frontend_dir.mkdir(exist_ok=True)
        
        # Create subdirectories
        (frontend_dir / "css").mkdir(exist_ok=True)
        (frontend_dir / "js").mkdir(exist_ok=True)
        
        # Create basic HTML file
        basic_html = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LanWorld - Complete LAN Ecosystem</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: #0f172a;
            color: #f8fafc;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            text-align: center;
            padding: 2rem;
            background: #1e293b;
            border-radius: 0.5rem;
            max-width: 600px;
        }
        h1 {
            color: #3b82f6;
        }
        .loading {
            margin: 2rem 0;
        }
        .loading:after {
            content: ' .';
            animation: dots 1.5s steps(5, end) infinite;
        }
        @keyframes dots {
            0%, 20% { color: rgba(0,0,0,0); text-shadow: .25em 0 0 rgba(0,0,0,0), .5em 0 0 rgba(0,0,0,0); }
            40% { color: white; text-shadow: .25em 0 0 rgba(0,0,0,0), .5em 0 0 rgba(0,0,0,0); }
            60% { text-shadow: .25em 0 0 white, .5em 0 0 rgba(0,0,0,0); }
            80%, 100% { text-shadow: .25em 0 0 white, .5em 0 0 white; }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🌐 LanWorld 2.0</h1>
        <p>Complete LAN Ecosystem with New Apps</p>
        <p>100% Local - Zero Cloud</p>
        <div class="loading">Loading full frontend</div>
        <p>If this message persists, please check that all frontend files are properly installed.</p>
    </div>
    <script>
        // Try to reload the page after 3 seconds
        setTimeout(() => location.reload(), 3000);
    </script>
</body>
</html>"""
        
        with open(frontend_dir / "index.html", "w", encoding="utf-8") as f:
            f.write(basic_html)
        
        print(f"✅ Created basic frontend structure at {frontend_dir.absolute()}")
        return True
    except Exception as e:
        print(f"❌ Failed to create frontend structure: {e}")
        return False

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n👋 LanWorld server stopped")
        print("Thank you for using LanWorld!")
    except Exception as e:
        print(f"\n❌ Error starting LanWorld: {e}")
        import traceback
        traceback.print_exc()
        print("\nTry installing dependencies with:")
        print("pip install fastapi uvicorn websockets bcrypt python-multipart")
        input("\nPress Enter to exit...")