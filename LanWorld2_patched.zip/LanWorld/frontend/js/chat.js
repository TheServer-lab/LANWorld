// Chat functionality

async function loadOnlineUsers() {
    try {
        const response = await fetch('/api/users/online', {
            headers: {'Authorization': `Bearer ${currentToken}`}
        });
        if (response.ok) {
            const users = await response.json();
            updateOnlineUsers(users);
        } else {
            console.error('Failed to load online users');
        }
    } catch(e) {
        console.error('Error loading users:', e);
        showNotification('Error loading users', 'error');
    }
}

function updateOnlineUsers(users) {
    const container = document.getElementById('usersList');
    
    if (!users || users.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">👤</div>
                <h3>No users online</h3>
                <p>Wait for others to join or invite them!</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = '';
    
    users.forEach(user => {
        if (user.id === currentUser.id) return;
        
        const userCard = document.createElement('div');
        userCard.className = `user-card ${user.id === currentChatUser ? 'active' : ''}`;
        userCard.dataset.userId = user.id;
        userCard.onclick = () => startChat(user);
        
        // Generate avatar color based on username
        const colors = ['#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16'];
        const colorIndex = user.username.charCodeAt(0) % colors.length;
        const avatarColor = colors[colorIndex];
        
        userCard.innerHTML = `
            <div class="user-avatar" style="background: ${avatarColor};">
                ${user.username.charAt(0).toUpperCase()}
            </div>
            <div class="user-info">
                <div class="user-name">${user.username}</div>
                <div class="user-status ${user.online ? 'status-online' : 'status-offline'}">
                    ${user.online ? '🟢 Online' : '⚫ Offline'}
                </div>
            </div>
        `;
        
        container.appendChild(userCard);
    });
}

function updateUserStatus(userId, online) {
    // Update the specific user's status
    const userCard = document.querySelector(`.user-card[data-user-id="${userId}"]`);
    if (userCard) {
        const statusEl = userCard.querySelector('.user-status');
        if (statusEl) {
            statusEl.textContent = online ? '🟢 Online' : '⚫ Offline';
            statusEl.className = `user-status ${online ? 'status-online' : 'status-offline'}`;
        }
    }
    
    // Reload the whole list to ensure consistency
    loadOnlineUsers();
}

function startChat(user) {
    console.log('Starting chat with:', user.username);
    
    currentChatUser = user.id;
    
    // Update UI
    document.getElementById('chatWith').textContent = `Chat with ${user.username}`;
    document.getElementById('chatHint').textContent = 'Type your message and press Enter to send';
    
    // Enable input field and button
    const messageInput = document.getElementById('messageInput');
    const sendButton = document.getElementById('sendButton');
    
    messageInput.disabled = false;
    messageInput.placeholder = "Type your message here...";
    sendButton.disabled = false;
    
    // Focus on the input field with a slight delay
    setTimeout(() => {
        messageInput.focus();
        messageInput.select();
    }, 50);
    
    // Update active state in user list
    document.querySelectorAll('.user-card').forEach(card => {
        card.classList.remove('active');
    });
    const activeCard = document.querySelector(`.user-card[data-user-id="${user.id}"]`);
    if (activeCard) {
        activeCard.classList.add('active');
    }
    
    // Load chat history
    loadChatHistory(user.id);
}

async function loadChatHistory(userId) {
    try {
        const response = await fetch(`/api/messages/${userId}`, {
            headers: {'Authorization': `Bearer ${currentToken}`}
        });
        
        if (response.ok) {
            const messages = await response.json();
            const container = document.getElementById('chatMessages');
            container.innerHTML = '';
            
            if (messages.length === 0) {
                container.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-state-icon">💬</div>
                        <h3>No messages yet</h3>
                        <p>Start the conversation!</p>
                    </div>
                `;
                return;
            }
            
            messages.forEach(msg => {
                addMessageToChat(msg, msg.sender_id === currentUser.id);
            });
            
            // Scroll to bottom
            container.scrollTop = container.scrollHeight;
        }
    } catch(e) {
        console.error('Error loading chat:', e);
        showNotification('Error loading chat history', 'error');
    }
}

function addMessageToChat(message, isSent) {
    const container = document.getElementById('chatMessages');
    
    // Remove empty state if present
    const emptyState = container.querySelector('.empty-state');
    if (emptyState) {
        emptyState.remove();
    }
    
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${isSent ? 'sent' : 'received'}`;
    
    const content = document.createElement('div');
    content.className = 'message-content';
    content.textContent = message.content;
    
    const time = document.createElement('div');
    time.className = 'message-time';
    const msgTime = new Date(message.timestamp);
    time.textContent = msgTime.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    
    messageDiv.appendChild(content);
    messageDiv.appendChild(time);
    container.appendChild(messageDiv);
    
    // Scroll to bottom
    container.scrollTop = container.scrollHeight;
}

async function sendMessage() {
    const input = document.getElementById('messageInput');
    const content = input.value.trim();
    
    if (!content || !currentChatUser) {
        showNotification('Please type a message first', 'warning');
        return;
    }
    
    // Clear typing indicator
    if (typingTimeout) {
        clearTimeout(typingTimeout);
        typingTimeout = null;
    }
    
    // Clear input immediately for better UX
    input.value = '';
    
    try {
        const response = await fetch('/api/messages', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentToken}`
            },
            body: JSON.stringify({
                recipient_id: currentChatUser,
                content: content,
                type: 'text'
            })
        });
        
        if (response.ok) {
            const message = await response.json();
            addMessageToChat(message, true);
            
            // Send via WebSocket if connected
            if (websocket && websocket.readyState === WebSocket.OPEN) {
                websocket.send(JSON.stringify({
                    type: 'message',
                    recipient_id: currentChatUser,
                    content: content
                }));
            }
        } else {
            const error = await response.json();
            showNotification('Failed to send message: ' + (error.detail || 'Unknown error'), 'error');
            // Restore message if failed
            input.value = content;
        }
    } catch(e) {
        console.error('Error sending message:', e);
        showNotification('Error sending message: ' + e.message, 'error');
        // Restore message if failed
        input.value = content;
    }
}

function showTypingIndicator(userId, isTyping) {
    const container = document.getElementById('chatMessages');
    let indicator = document.getElementById('typing-indicator');
    
    if (isTyping && !indicator) {
        indicator = document.createElement('div');
        indicator.id = 'typing-indicator';
        indicator.className = 'message received';
        indicator.innerHTML = `
            <div class="message-content" style="background: var(--bg-tertiary); color: var(--text-secondary); font-style: italic;">
                <span class="typing-dots">
                    <span>.</span><span>.</span><span>.</span>
                </span>
            </div>
        `;
        container.appendChild(indicator);
        container.scrollTop = container.scrollHeight;
    } else if (!isTyping && indicator) {
        indicator.remove();
    }
}

// Export to global scope
window.loadOnlineUsers = loadOnlineUsers;
window.updateUserStatus = updateUserStatus;
window.startChat = startChat;
window.loadChatHistory = loadChatHistory;
window.addMessageToChat = addMessageToChat;
window.sendMessage = sendMessage;
window.showTypingIndicator = showTypingIndicator;