// Groups functionality (Discord-like)

function showCreateGroupModal() {
    // Create modal if it doesn't exist
    if (!document.getElementById('createGroupModal')) {
        createGroupModal();
    }
    showModal('createGroupModal');
    document.getElementById('groupNameInput').focus();
}

function createGroupModal() {
    const modal = document.createElement('div');
    modal.id = 'createGroupModal';
    modal.className = 'hidden';
    modal.style = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center;';
    
    modal.innerHTML = `
        <div style="background: var(--bg-secondary); padding: 2rem; border-radius: 0.5rem; width: 90%; max-width: 500px;">
            <h3 style="margin-bottom: 1rem;">Create New Group</h3>
            <div class="form-group">
                <input type="text" id="groupNameInput" class="form-control" placeholder="Group Name">
            </div>
            <div class="form-group">
                <textarea id="groupDescriptionInput" class="form-control" placeholder="Description (optional)" rows="3"></textarea>
            </div>
            <div class="form-group">
                <label style="display: flex; align-items: center; gap: 0.5rem;">
                    <input type="checkbox" id="groupIsPublic" checked>
                    <span>Public Group (Anyone can join)</span>
                </label>
            </div>
            <div style="display: flex; gap: 0.5rem; margin-top: 1rem;">
                <button onclick="createGroup()" class="btn btn-pink flex-1">Create</button>
                <button onclick="hideModal('createGroupModal')" class="btn btn-danger">Cancel</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

async function loadGroups(tab = 'my') {
    activeGroupsTab = tab;
    
    // Update active tab
    document.querySelectorAll('#groupsTabs .tab-button').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector(`#groupsTabs .tab-button[onclick*="${tab}"]`).classList.add('active');
    
    try {
        let url = '/api/groups';
        if (tab === 'public') {
            url = '/api/groups/public';
        }
        
        const response = await fetch(url, {
            headers: tab === 'public' ? {} : {'Authorization': `Bearer ${currentToken}`}
        });
        
        if (response.ok) {
            const groups = await response.json();
            const container = document.getElementById('groupsList');
            
            if (!groups || groups.length === 0) {
                container.innerHTML = `
                    <div class="empty-state" style="grid-column: 1 / -1;">
                        <div class="empty-state-icon">👥</div>
                        <h3>No groups yet</h3>
                        <p>Create or join a group to start chatting!</p>
                    </div>
                `;
                return;
            }
            
            container.innerHTML = '';
            
            groups.forEach(group => {
                const groupCard = document.createElement('div');
                groupCard.className = 'group-card';
                groupCard.onclick = () => openGroupChat(group.id);
                
                const isMember = group.members && group.members.includes(currentUser?.id);
                
                groupCard.innerHTML = `
                    <div class="group-header">
                        <div class="group-avatar">
                            ${group.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                            <h3 class="group-name">${escapeHtml(group.name)}</h3>
                            ${group.is_public ? '<span class="public-badge">Public</span>' : '<span style="background: #6b7280; color: white; padding: 0.25rem 0.75rem; border-radius: 1rem; font-size: 0.75rem;">Private</span>'}
                        </div>
                    </div>
                    <div class="group-description">
                        ${escapeHtml(group.description || 'No description')}
                    </div>
                    <div class="group-stats">
                        <span>👥 ${group.member_count || 0} members</span>
                        <span>Created by ${group.creator_username}</span>
                    </div>
                    <div style="margin-top: 1rem;">
                        ${isMember ? 
                            '<button class="btn btn-sm btn-success w-full" disabled>Member</button>' :
                            '<button class="btn btn-sm btn-pink w-full" onclick="joinGroup(event, \'' + group.id + '\')">Join Group</button>'
                        }
                    </div>
                `;
                
                container.appendChild(groupCard);
            });
        }
    } catch(e) {
        console.error('Error loading groups:', e);
        showNotification('Error loading groups', 'error');
    }
}

async function createGroup() {
    const name = document.getElementById('groupNameInput').value.trim();
    const description = document.getElementById('groupDescriptionInput').value.trim();
    const isPublic = document.getElementById('groupIsPublic').checked;
    
    if (!name) {
        showNotification('Please enter a group name', 'warning');
        return;
    }
    
    try {
        const response = await fetch('/api/groups', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentToken}`
            },
            body: JSON.stringify({
                name,
                description,
                is_public: isPublic,
                members: []
            })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            hideModal('createGroupModal');
            showNotification('Group created successfully!', 'success');
            document.getElementById('groupNameInput').value = '';
            document.getElementById('groupDescriptionInput').value = '';
            loadGroups(activeGroupsTab);
        } else {
            showNotification('Failed to create group: ' + (data.detail || 'Unknown error'), 'error');
        }
    } catch(e) {
        showNotification('Error creating group: ' + e.message, 'error');
        console.error('Error creating group:', e);
    }
}

async function joinGroup(event, groupId) {
    event.stopPropagation(); // Prevent card click
    
    try {
        const response = await fetch(`/api/groups/${groupId}/join`, {
            method: 'POST',
            headers: {'Authorization': `Bearer ${currentToken}`}
        });
        
        if (response.ok) {
            showNotification('Joined group successfully!', 'success');
            loadGroups(activeGroupsTab);
        } else {
            showNotification('Failed to join group', 'error');
        }
    } catch(e) {
        console.error('Error joining group:', e);
        showNotification('Error joining group', 'error');
    }
}

function openGroupChat(groupId) {
    // In a real implementation, you would open a group chat interface
    // For now, show a message
    showNotification('Group chat feature coming soon!', 'info');
}

// Export to global scope
window.showCreateGroupModal = showCreateGroupModal;
window.createGroup = createGroup;
window.joinGroup = joinGroup;
window.openGroupChat = openGroupChat;
window.loadGroups = loadGroups;