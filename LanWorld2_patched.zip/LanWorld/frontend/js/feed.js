// Social feed functionality

async function createPost() {
    const content = document.getElementById('postContent').value.trim();
    if (!content) {
        showNotification('Please enter some content for your post', 'warning');
        return;
    }
    
    try {
        const response = await fetch('/api/feed/posts', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentToken}`
            },
            body: JSON.stringify({content})
        });
        
        const data = await response.json();
        
        if (response.ok) {
            document.getElementById('postContent').value = '';
            showNotification('Post created successfully!', 'success');
            loadPosts();
        } else {
            showNotification('Failed to create post: ' + (data.detail || 'Unknown error'), 'error');
        }
    } catch(e) {
        showNotification('Error creating post: ' + e.message, 'error');
        console.error('Error creating post:', e);
    }
}

async function loadPosts() {
    try {
        const response = await fetch('/api/feed/posts', {
            headers: {'Authorization': `Bearer ${currentToken}`}
        });
        
        if (response.ok) {
            const posts = await response.json();
            const container = document.getElementById('postsList');
            
            if (!posts || posts.length === 0) {
                container.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-state-icon">📝</div>
                        <h3>No posts yet</h3>
                        <p>Be the first to post on the LAN feed!</p>
                    </div>
                `;
                return;
            }
            
            container.innerHTML = '';
            
            posts.forEach(post => {
                const postCard = document.createElement('div');
                postCard.className = 'post-card';
                postCard.id = `post-${post.id}`;
                
                // Generate avatar color
                const colors = ['#3b82f6', '#ef4444', '#10b981', '#f59e0b'];
                const colorIndex = post.author_username.charCodeAt(0) % colors.length;
                const avatarColor = colors[colorIndex];
                
                postCard.innerHTML = `
                    <div class="post-header">
                        <div class="user-avatar" style="background: ${avatarColor}; margin-right: 1rem;">
                            ${post.author_username?.charAt(0).toUpperCase() || 'U'}
                        </div>
                        <div>
                            <div class="user-name">${post.author_username || 'Unknown'}</div>
                            <div class="user-status">${new Date(post.timestamp).toLocaleString()}</div>
                        </div>
                    </div>
                    <div class="post-content">${escapeHtml(post.content)}</div>
                    <div class="post-actions">
                        <button class="post-action ${post.liked ? 'active like' : ''}" onclick="likePost('${post.id}')">
                            <span>${post.liked ? '❤️' : '🤍'}</span> ${post.like_count || 0}
                        </button>
                        <button class="post-action" onclick="showComments('${post.id}')">
                            <span>💬</span> ${post.comments_count || 0}
                        </button>
                    </div>
                    <div id="comments-${post.id}" class="comments-section hidden">
                        <div class="comment-form">
                            <textarea class="comment-input" id="comment-input-${post.id}" placeholder="Write a comment..."></textarea>
                            <button class="btn btn-sm" onclick="addComment('${post.id}')">Post Comment</button>
                        </div>
                        <div id="comments-list-${post.id}"></div>
                    </div>
                `;
                
                container.appendChild(postCard);
            });
        }
    } catch(e) {
        console.error('Error loading posts:', e);
        showNotification('Error loading posts', 'error');
    }
}

async function likePost(postId) {
    try {
        const response = await fetch(`/api/feed/posts/${postId}/like`, {
            method: 'POST',
            headers: {'Authorization': `Bearer ${currentToken}`}
        });
        
        if (response.ok) {
            const result = await response.json();
            const likeBtn = document.querySelector(`#post-${postId} .post-action`);
            const likeCount = likeBtn.querySelector('span + span') || document.createElement('span');
            
            if (result.liked) {
                likeBtn.classList.add('active', 'like');
                likeBtn.innerHTML = '<span>❤️</span> ' + (parseInt(likeCount.textContent || '0') + 1);
            } else {
                likeBtn.classList.remove('active', 'like');
                likeBtn.innerHTML = '<span>🤍</span> ' + (parseInt(likeCount.textContent || '1') - 1);
            }
        }
    } catch(e) {
        console.error('Error liking post:', e);
    }
}

function showComments(postId) {
    const commentsSection = document.getElementById(`comments-${postId}`);
    commentsSection.classList.toggle('hidden');
    
    if (!commentsSection.classList.contains('hidden')) {
        loadComments(postId);
    }
}

async function loadComments(postId) {
    try {
        const response = await fetch(`/api/feed/posts/${postId}/comments`, {
            headers: {'Authorization': `Bearer ${currentToken}`}
        });
        
        if (response.ok) {
            const comments = await response.json();
            const container = document.getElementById(`comments-list-${postId}`);
            container.innerHTML = '';
            
            comments.forEach(comment => {
                const commentEl = document.createElement('div');
                commentEl.className = 'comment';
                
                commentEl.innerHTML = `
                    <div class="comment-header">
                        <span class="comment-author">${comment.author_username}</span>
                        <span class="comment-time">${new Date(comment.timestamp).toLocaleString()}</span>
                    </div>
                    <div class="comment-content">${escapeHtml(comment.content)}</div>
                `;
                
                container.appendChild(commentEl);
            });
        }
    } catch(e) {
        console.error('Error loading comments:', e);
    }
}

async function addComment(postId) {
    const input = document.getElementById(`comment-input-${postId}`);
    const content = input.value.trim();
    
    if (!content) {
        showNotification('Please enter a comment', 'warning');
        return;
    }
    
    try {
        const response = await fetch(`/api/feed/posts/${postId}/comments`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentToken}`
            },
            body: JSON.stringify({content})
        });
        
        if (response.ok) {
            input.value = '';
            loadComments(postId);
            
            // Update comment count
            const commentBtn = document.querySelector(`#post-${postId} .post-action:nth-child(2)`);
            const count = parseInt(commentBtn.textContent.match(/\d+/)?.[0] || '0') + 1;
            commentBtn.innerHTML = `<span>💬</span> ${count}`;
        }
    } catch(e) {
        console.error('Error adding comment:', e);
        showNotification('Error adding comment', 'error');
    }
}

// Export to global scope
window.createPost = createPost;
window.loadPosts = loadPosts;
window.likePost = likePost;
window.showComments = showComments;
window.loadComments = loadComments;
window.addComment = addComment;