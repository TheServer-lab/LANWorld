// Authentication functions

function showAuthTab(tab) {
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    document.getElementById('loginForm').classList.add('hidden');
    document.getElementById('registerForm').classList.add('hidden');
    
    if (tab === 'login') {
        document.querySelector('.auth-tab:nth-child(1)').classList.add('active');
        document.getElementById('loginForm').classList.remove('hidden');
        document.getElementById('loginUsername').focus();
    } else {
        document.querySelector('.auth-tab:nth-child(2)').classList.add('active');
        document.getElementById('registerForm').classList.remove('hidden');
        document.getElementById('registerUsername').focus();
    }
}

async function login() {
    const username = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value;
    
    if (!username || !password) {
        showNotification('Please enter both username and password', 'warning');
        return;
    }
    
    try {
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({username, password})
        });
        
        const data = await response.json();
        
        if (response.ok) {
            currentUser = data.user;
            currentToken = data.token;
            showMainApp();
            connectWebSocket();
            showNotification('Login successful!', 'success');
        } else {
            showNotification('Login failed: ' + (data.detail || 'Unknown error'), 'error');
        }
    } catch(e) {
        showNotification('Login error: ' + e.message, 'error');
        console.error('Login error:', e);
    }
}

async function register() {
    const username = document.getElementById('registerUsername').value.trim();
    const password = document.getElementById('registerPassword').value;
    const bio = document.getElementById('registerBio').value.trim() || '';
    
    if (!username || !password) {
        showNotification('Please enter both username and password', 'warning');
        return;
    }
    
    if (username.length < 3) {
        showNotification('Username must be at least 3 characters', 'warning');
        return;
    }
    
    if (password.length < 6) {
        showNotification('Password must be at least 6 characters', 'warning');
        return;
    }
    
    try {
        const response = await fetch('/api/auth/register', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({username, password, bio})
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showNotification('Registration successful! Please login.', 'success');
            showAuthTab('login');
            document.getElementById('loginUsername').value = username;
            document.getElementById('loginPassword').value = '';
            document.getElementById('loginUsername').focus();
        } else {
            showNotification('Registration failed: ' + (data.detail || 'Unknown error'), 'error');
        }
    } catch(e) {
        showNotification('Registration error: ' + e.message, 'error');
        console.error('Registration error:', e);
    }
}

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        if (websocket) {
            websocket.close();
        }
        currentUser = null;
        currentToken = null;
        currentChatUser = null;
        document.getElementById('app').classList.add('hidden');
        document.getElementById('authView').classList.remove('hidden');
        showNotification('Logged out successfully', 'info');
    }
}

function showMainApp() {
    document.getElementById('authView').classList.add('hidden');
    document.getElementById('app').classList.remove('hidden');
    document.getElementById('currentUsername').textContent = currentUser.username;
    showView('chat');
}

// Export to global scope
window.showAuthTab = showAuthTab;
window.login = login;
window.register = register;
window.logout = logout;
window.showMainApp = showMainApp;