// Text Dump functionality (Pastebin-like)

function showCreateTextDumpModal() {
    // Create modal if it doesn't exist
    if (!document.getElementById('createTextDumpModal')) {
        createTextDumpModal();
    }
    showModal('createTextDumpModal');
    document.getElementById('textDumpTitle').focus();
}

function createTextDumpModal() {
    const modal = document.createElement('div');
    modal.id = 'createTextDumpModal';
    modal.className = 'hidden';
    modal.style = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center;';
    
    modal.innerHTML = `
        <div style="background: var(--bg-secondary); padding: 2rem; border-radius: 0.5rem; width: 90%; max-width: 600px;">
            <h3 style="margin-bottom: 1rem;">Create Text Dump</h3>
            <div class="form-group">
                <input type="text" id="textDumpTitle" class="form-control" placeholder="Title">
            </div>
            <div class="form-group">
                <textarea id="textDumpContent" class="form-control" placeholder="Paste your text or code here..." rows="10" style="font-family: monospace;"></textarea>
            </div>
            <div class="form-group">
                <select id="textDumpLanguage" class="form-control">
                    <option value="text">Plain Text</option>
                    <option value="python">Python</option>
                    <option value="javascript">JavaScript</option>
                    <option value="html">HTML</option>
                    <option value="css">CSS</option>
                    <option value="json">JSON</option>
                    <option value="markdown">Markdown</option>
                </select>
            </div>
            <div class="form-group">
                <select id="textDumpVisibility" class="form-control">
                    <option value="private">Private (Only you)</option>
                    <option value="public">Public (Everyone)</option>
                    <option value="unlisted">Unlisted (Anyone with link)</option>
                </select>
            </div>
            <div style="display: flex; gap: 0.5rem; margin-top: 1rem;">
                <button onclick="createTextDump()" class="btn btn-warning flex-1">Create</button>
                <button onclick="hideModal('createTextDumpModal')" class="btn btn-danger">Cancel</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

async function loadTextDumps(tab = 'my') {
    activeTextDumpTab = tab;
    
    // Update active tab
    document.querySelectorAll('#textdumpTabs .tab-button').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector(`#textdumpTabs .tab-button[onclick*="${tab}"]`).classList.add('active');
    
    try {
        let url = '/api/textdump';
        if (tab === 'public') {
            url = '/api/textdump/public';
        }
        
        const response = await fetch(url, {
            headers: tab === 'public' ? {} : {'Authorization': `Bearer ${currentToken}`}
        });
        
        if (response.ok) {
            const dumps = await response.json();
            const container = document.getElementById('textDumpsList');
            
            if (!dumps || dumps.length === 0) {
                container.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-state-icon">📄</div>
                        <h3>No text dumps yet</h3>
                        <p>Create your first text dump to share code or text!</p>
                    </div>
                `;
                return;
            }
            
            container.innerHTML = '';
            
            dumps.forEach(dump => {
                const dumpCard = document.createElement('div');
                dumpCard.className = 'textdump-card';
                
                // Truncate content for preview
                const preview = dump.content.length > 200 ? 
                    dump.content.substring(0, 200) + '...' : dump.content;
                
                dumpCard.innerHTML = `
                    <div class="textdump-header">
                        <h3 class="textdump-title">${escapeHtml(dump.title)}</h3>
                        <span class="language-badge">${dump.language || 'text'}</span>
                    </div>
                    <div class="textdump-meta">
                        <span>By ${dump.owner_id === currentUser?.id ? 'You' : dump.owner_id || 'Unknown'}</span>
                        <span>${new Date(dump.created_at).toLocaleDateString()}</span>
                        <span>👁️ ${dump.views || 0} views</span>
                    </div>
                    <div class="code-block">
                        <pre>${escapeHtml(preview)}</pre>
                    </div>
                    <div style="display: flex; gap: 0.5rem;">
                        <button class="btn btn-sm" onclick="viewTextDump('${dump.id}')">View Full</button>
                        ${dump.owner_id === currentUser?.id ? 
                            `<button class="btn btn-sm btn-danger" onclick="deleteTextDump('${dump.id}')">Delete</button>` : ''}
                    </div>
                `;
                
                container.appendChild(dumpCard);
            });
        }
    } catch(e) {
        console.error('Error loading text dumps:', e);
        showNotification('Error loading text dumps', 'error');
    }
}

async function createTextDump() {
    const title = document.getElementById('textDumpTitle').value.trim();
    const content = document.getElementById('textDumpContent').value.trim();
    const language = document.getElementById('textDumpLanguage').value;
    const visibility = document.getElementById('textDumpVisibility').value;
    
    if (!title || !content) {
        showNotification('Please enter both title and content', 'warning');
        return;
    }
    
    try {
        const response = await fetch('/api/textdump', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentToken}`
            },
            body: JSON.stringify({
                title,
                content,
                language,
                visibility
            })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            hideModal('createTextDumpModal');
            showNotification('Text dump created successfully!', 'success');
            document.getElementById('textDumpTitle').value = '';
            document.getElementById('textDumpContent').value = '';
            loadTextDumps(activeTextDumpTab);
        } else {
            showNotification('Failed to create text dump: ' + (data.detail || 'Unknown error'), 'error');
        }
    } catch(e) {
        showNotification('Error creating text dump: ' + e.message, 'error');
        console.error('Error creating text dump:', e);
    }
}

function viewTextDump(dumpId) {
    window.open(`/api/textdump/${dumpId}`, '_blank');
}

async function deleteTextDump(dumpId) {
    if (!confirm('Are you sure you want to delete this text dump?')) {
        return;
    }
    
    try {
        const response = await fetch(`/api/textdump/${dumpId}`, {
            method: 'DELETE',
            headers: {'Authorization': `Bearer ${currentToken}`}
        });
        
        if (response.ok) {
            showNotification('Text dump deleted successfully', 'success');
            loadTextDumps(activeTextDumpTab);
        }
    } catch(e) {
        console.error('Error deleting text dump:', e);
        showNotification('Error deleting text dump', 'error');
    }
}

// Export to global scope
window.showCreateTextDumpModal = showCreateTextDumpModal;
window.createTextDump = createTextDump;
window.viewTextDump = viewTextDump;
window.deleteTextDump = deleteTextDump;
window.loadTextDumps = loadTextDumps;