// Forms functionality (Reddit-like)

function showCreateFormModal() {
    // Create modal if it doesn't exist
    if (!document.getElementById('createFormModal')) {
        createFormModal();
    }
    showModal('createFormModal');
    document.getElementById('formTitleInput').focus();
}

function createFormModal() {
    const modal = document.createElement('div');
    modal.id = 'createFormModal';
    modal.className = 'hidden';
    modal.style = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center;';
    
    modal.innerHTML = `
        <div style="background: var(--bg-secondary); padding: 2rem; border-radius: 0.5rem; width: 90%; max-width: 500px;">
            <h3 style="margin-bottom: 1rem;">Create New Form</h3>
            <div class="form-group">
                <input type="text" id="formTitleInput" class="form-control" placeholder="Title">
            </div>
            <div class="form-group">
                <textarea id="formContentInput" class="form-control" placeholder="Content" rows="4"></textarea>
            </div>
            <div class="form-group">
                <select id="formCategoryInput" class="form-control">
                    <option value="general">General</option>
                    <option value="discussion">Discussion</option>
                    <option value="question">Question</option>
                    <option value="announcement">Announcement</option>
                </select>
            </div>
            <div style="display: flex; gap: 0.5rem; margin-top: 1rem;">
                <button onclick="createForm()" class="btn btn-purple flex-1">Create</button>
                <button onclick="hideModal('createFormModal')" class="btn btn-danger">Cancel</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

async function loadForms(category = '') {
    activeFormCategory = category;
    
    // Update active tab
    document.querySelectorAll('#formCategories .tab-button').forEach(btn => {
        btn.classList.remove('active');
    });
    if (category) {
        document.querySelector(`#formCategories .tab-button[onclick*="${category}"]`).classList.add('active');
    } else {
        document.querySelector('#formCategories .tab-button:first-child').classList.add('active');
    }
    
    try {
        const url = category ? `/api/forms?category=${category}` : '/api/forms';
        const response = await fetch(url, {
            headers: {'Authorization': `Bearer ${currentToken}`}
        });
        
        if (response.ok) {
            const forms = await response.json();
            const container = document.getElementById('formsList');
            
            if (!forms || forms.length === 0) {
                container.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-state-icon">📋</div>
                        <h3>No forms yet</h3>
                        <p>Create the first form to start discussions!</p>
                    </div>
                `;
                return;
            }
            
            container.innerHTML = '';
            
            forms.forEach(form => {
                const formCard = document.createElement('div');
                formCard.className = 'form-card';
                
                formCard.innerHTML = `
                    <div class="vote-widget">
                        <button class="vote-btn up" onclick="voteForm('${form.id}', 'up')">⬆️</button>
                        <div class="vote-count">${form.score || 0}</div>
                        <button class="vote-btn down" onclick="voteForm('${form.id}', 'down')">⬇️</button>
                    </div>
                    <div class="form-content">
                        <div class="form-meta">
                            <span class="category-badge">${form.category || 'general'}</span>
                            <span>Posted by ${form.author_username}</span>
                            <span>${new Date(form.created_at).toLocaleDateString()}</span>
                        </div>
                        <h3 class="form-title">${escapeHtml(form.title)}</h3>
                        <div class="form-description">${escapeHtml(form.content)}</div>
                        <div class="form-stats">
                            <span>💬 ${form.responses_count || 0} responses</span>
                            <span>⬆️ ${form.upvotes || 0}</span>
                            <span>⬇️ ${form.downvotes || 0}</span>
                        </div>
                    </div>
                `;
                
                container.appendChild(formCard);
            });
        }
    } catch(e) {
        console.error('Error loading forms:', e);
        showNotification('Error loading forms', 'error');
    }
}

async function createForm() {
    const title = document.getElementById('formTitleInput').value.trim();
    const content = document.getElementById('formContentInput').value.trim();
    const category = document.getElementById('formCategoryInput').value;
    
    if (!title || !content) {
        showNotification('Please enter both title and content', 'warning');
        return;
    }
    
    try {
        const response = await fetch('/api/forms', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentToken}`
            },
            body: JSON.stringify({
                title,
                content,
                category,
                tags: []
            })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            hideModal('createFormModal');
            showNotification('Form created successfully!', 'success');
            document.getElementById('formTitleInput').value = '';
            document.getElementById('formContentInput').value = '';
            loadForms(activeFormCategory);
        } else {
            showNotification('Failed to create form: ' + (data.detail || 'Unknown error'), 'error');
        }
    } catch(e) {
        showNotification('Error creating form: ' + e.message, 'error');
        console.error('Error creating form:', e);
    }
}

async function voteForm(formId, voteType) {
    try {
        const response = await fetch(`/api/forms/${formId}/vote?vote_type=${voteType}`, {
            method: 'POST',
            headers: {'Authorization': `Bearer ${currentToken}`}
        });
        
        if (response.ok) {
            loadForms(activeFormCategory);
        }
    } catch(e) {
        console.error('Error voting:', e);
    }
}

// Export to global scope
window.showCreateFormModal = showCreateFormModal;
window.createForm = createForm;
window.voteForm = voteForm;
window.loadForms = loadForms;