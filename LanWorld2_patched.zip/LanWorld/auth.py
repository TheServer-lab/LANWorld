"""
Authentication module
"""

import hashlib
import secrets
import uuid
from datetime import datetime, timedelta
from typing import Optional

from fastapi import APIRouter, HTTPException, Header, Depends
from fastapi.responses import JSONResponse

from models import UserCreate, UserLogin
from storage import storage

router = APIRouter()

# Utility functions
def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return hash_password(plain_password) == hashed_password

def create_session_token(user_id: str) -> str:
    token = secrets.token_urlsafe(32)
    expires_at = (datetime.now() + timedelta(days=7)).isoformat()
    storage.add_session(token, user_id, expires_at)
    return token

def verify_session_token(token: str) -> Optional[str]:
    session = storage.get_session(token)
    if session:
        expires_at = datetime.fromisoformat(session["expires_at"])
        if expires_at > datetime.now():
            return session["user_id"]
    return None

# Dependency
async def get_current_user(authorization: Optional[str] = Header(None)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    token = authorization[7:]
    user_id = verify_session_token(token)
    
    if not user_id:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    
    return user_id

# API endpoints
@router.post("/register")
async def register(user_data: UserCreate):
    try:
        existing_user = storage.get_user_by_username(user_data.username)
        if existing_user:
            return JSONResponse(
                status_code=400,
                content={"detail": "Username already exists"}
            )
        
        user_id = str(uuid.uuid4())
        password_hash = hash_password(user_data.password)
        
        user_record = {
            "id": user_id,
            "username": user_data.username,
            "password_hash": password_hash,
            "avatar": "default.png",
            "bio": user_data.bio,
            "online": False,
            "created_at": datetime.now().isoformat(),
            "last_seen": datetime.now().isoformat()
        }
        
        storage.create_user(user_id, user_record)
        storage.write_account(user_data.username, password_hash)
        
        return {"message": "User created successfully"}
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"detail": f"Registration failed: {str(e)}"}
        )

@router.post("/login")
async def login(user_data: UserLogin):
    try:
        user = storage.get_user_by_username(user_data.username)
        if not user:
            return JSONResponse(
                status_code=401,
                content={"detail": "Invalid credentials"}
            )
        
        if not verify_password(user_data.password, user["password_hash"]):
            return JSONResponse(
                status_code=401,
                content={"detail": "Invalid credentials"}
            )
        
        storage.update_user(user["id"], {"online": True, "last_seen": datetime.now().isoformat()})
        token = create_session_token(user["id"])
        
        return {
            "token": token,
            "user": {
                "id": user["id"],
                "username": user["username"],
                "avatar": user["avatar"],
                "bio": user["bio"]
            }
        }
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"detail": f"Login failed: {str(e)}"}
        )

@router.get("/validate")
async def validate_token(current_user: str = Depends(get_current_user)):
    user = storage.get_user_by_id(current_user)
    if user:
        return {"user": user}
    raise HTTPException(status_code=404, detail="User not found")