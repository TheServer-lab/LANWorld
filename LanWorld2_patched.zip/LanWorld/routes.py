"""
General routes and frontend for LanWorld
"""

import socket
from pathlib import Path

from fastapi import APIRouter
from fastapi.responses import HTMLResponse

from config import CONFIG
from storage import storage

router = APIRouter()

# Get the base directory (where LanWorld.py is located)
BASE_DIR = Path(__file__).parent
FRONTEND_DIR = BASE_DIR / "frontend"

# Read the HTML template once when the module loads
INDEX_HTML = None
if (FRONTEND_DIR / "index.html").exists():
    with open(FRONTEND_DIR / "index.html", "r", encoding="utf-8") as f:
        INDEX_HTML = f.read()
else:
    # Fallback to embedded HTML if frontend directory doesn't exist
    INDEX_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LanWorld - Complete LAN Ecosystem</title>
    <style>
        /* Basic styles for error page */
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: #0f172a;
            color: #f8fafc;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .error-container {
            text-align: center;
            padding: 2rem;
            background: #1e293b;
            border-radius: 0.5rem;
            max-width: 500px;
        }
        h1 {
            color: #ef4444;
        }
    </style>
</head>
<body>
    <div class="error-container">
        <h1>⚠️ Frontend Files Not Found</h1>
        <p>The frontend directory was not found in the base directory.</p>
        <p>Please make sure the 'frontend' folder exists in the same directory as LanWorld.py</p>
        <p>Expected path: <code>{FRONTEND_DIR}</code></p>
        <button onclick="location.reload()" style="padding: 0.5rem 1rem; background: #3b82f6; color: white; border: none; border-radius: 0.25rem; cursor: pointer;">
            Retry
        </button>
    </div>
</body>
</html>"""

@router.get("/", response_class=HTMLResponse)
async def serve_frontend():
    """Serve the main HTML page"""
    return HTMLResponse(content=INDEX_HTML)

@router.get("/api/discovery/info")
async def get_discovery_info():
    try:
        online_users = storage.get_online_users()
        return {
            "name": "LanWorld",
            "version": "2.0",
            "host": socket.gethostbyname(socket.gethostname()),
            "port": CONFIG["port"],
            "users_online": len(online_users)
        }
    except:
        return {
            "name": "LanWorld",
            "version": "2.0",
            "host": "localhost",
            "port": CONFIG["port"],
            "users_online": 0
        }