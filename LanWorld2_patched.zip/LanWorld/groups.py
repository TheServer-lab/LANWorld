"""
Group chat module for Discord-like functionality
"""

import uuid
from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from storage import storage
from auth import get_current_user, verify_session_token
import asyncio
import json

router = APIRouter()

class GroupCreate(BaseModel):
    name: str
    description: str = ""
    is_public: bool = True
    members: List[str] = []

class GroupMessageCreate(BaseModel):
    group_id: str
    content: str
    type: str = "text"


def _ensure_members_list(group: dict) -> list:
    """Normalize the members field for a group to always be a list."""
    members = group.get("members", [])
    if isinstance(members, list):
        return members
    if isinstance(members, dict):
        # dict of user_id -> metadata -> convert to list of keys or values depending on shape
        # prefer keys (user ids)
        try:
            return list(members.keys())
        except Exception:
            return list(members.values())
    # any other singular value -> wrap into list
    return [members]

# WebSocket connection manager for groups
class GroupConnectionManager:
    def __init__(self):
        self.active_connections: dict = {}
        self.group_connections: dict = {}
    
    async def connect(self, websocket: WebSocket, group_id: str, user_id: str):
        await websocket.accept()
        
        if group_id not in self.group_connections:
            self.group_connections[group_id] = {}
        
        self.group_connections[group_id][user_id] = websocket
        self.active_connections[user_id] = websocket
        
        # Notify group of new member
        await self.broadcast_to_group(group_id, {
            "type": "member_joined",
            "user_id": user_id,
            "timestamp": datetime.now().isoformat()
        }, exclude_user=user_id)
    
    def disconnect(self, group_id: str, user_id: str):
        if group_id in self.group_connections and user_id in self.group_connections[group_id]:
            del self.group_connections[group_id][user_id]
        
        if user_id in self.active_connections:
            del self.active_connections[user_id]
    
    async def send_to_user(self, user_id: str, message: dict):
        if user_id in self.active_connections:
            try:
                await self.active_connections[user_id].send_json(message)
            except:
                pass
    
    async def broadcast_to_group(self, group_id: str, message: dict, exclude_user: str = None):
        if group_id in self.group_connections:
            for user_id, websocket in self.group_connections[group_id].items():
                if user_id != exclude_user:
                    try:
                        await websocket.send_json(message)
                    except:
                        pass

group_manager = GroupConnectionManager()

@router.websocket("/ws/group/{group_id}")
async def group_websocket_endpoint(websocket: WebSocket, group_id: str, token: str):
    user_id = verify_session_token(token)
    if not user_id:
        await websocket.close(code=1008)
        return
    
    # Check if user is member of group
    group = storage.get_group(group_id)
    if not group:
        await websocket.close(code=1008)
        return
    members = _ensure_members_list(group)
    if user_id not in members:
        await websocket.close(code=1008)
        return
    
    await group_manager.connect(websocket, group_id, user_id)
    
    try:
        # Send group info and recent messages
        group_messages = storage.get_group_messages(group_id)[-50:]  # Last 50 messages
        await websocket.send_json({
            "type": "group_info",
            "group": group,
            "messages": group_messages
        })
        
        while True:
            try:
                data = await websocket.receive_json()
                
                if data["type"] == "message":
                    message_id = str(uuid.uuid4())
                    message = {
                        "id": message_id,
                        "group_id": group_id,
                        "sender_id": user_id,
                        "content": data["content"],
                        "type": data.get("type", "text"),
                        "timestamp": datetime.now().isoformat()
                    }
                    
                    storage.add_group_message(message)
                    
                    # Broadcast to group
                    await group_manager.broadcast_to_group(group_id, {
                        "type": "message",
                        **message
                    })
                    
                elif data["type"] == "typing":
                    await group_manager.broadcast_to_group(group_id, {
                        "type": "typing",
                        "user_id": user_id,
                        "is_typing": data.get("is_typing", True)
                    }, exclude_user=user_id)
                    
            except json.JSONDecodeError:
                pass
            except WebSocketDisconnect:
                break
                
    except WebSocketDisconnect:
        pass
    except Exception as e:
        print(f"Group WebSocket error: {e}")
    finally:
        group_manager.disconnect(group_id, user_id)

@router.post("/groups")
async def create_group(group: GroupCreate, current_user: str = Depends(get_current_user)):
    try:
        group_id = str(uuid.uuid4())
        user = storage.get_user_by_id(current_user)
        
        # Ensure creator is in members (normalize incoming members)
        incoming_members = list(group.members) if isinstance(group.members, list) else []
        members = list(dict.fromkeys(incoming_members + [current_user]))
        
        group_data = {
            "id": group_id,
            "name": group.name,
            "description": group.description,
            "creator_id": current_user,
            "creator_username": user.get("username", "Unknown") if user else "Unknown",
            "members": members,
            "is_public": group.is_public,
            "created_at": datetime.now().isoformat(),
            "member_count": len(members)
        }
        
        storage.add_group(group_data)
        return group_data
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"detail": f"Failed to create group: {str(e)}"}
        )

@router.get("/groups")
async def get_groups(current_user: str = Depends(get_current_user)):
    try:
        groups = storage.get_groups(current_user)
        # Ensure members list types are normalized for safety
        for g in groups:
            g["members"] = _ensure_members_list(g)
        return groups
    except:
        return []

@router.get("/groups/public")
async def get_public_groups():
    try:
        data = storage.read_data()
        public_groups = [g for g in data.get("groups", []) if g.get("is_public", False)]
        # normalize members
        for g in public_groups:
            g["members"] = _ensure_members_list(g)
        return public_groups
    except:
        return []

@router.post("/groups/{group_id}/join")
async def join_group(group_id: str, current_user: str = Depends(get_current_user)):
    try:
        data = storage.read_data()
        for group in data.get("groups", []):
            if group.get("id") == group_id:
                members = _ensure_members_list(group)
                if current_user not in members:
                    members.append(current_user)
                    group["members"] = members
                    group["member_count"] = len(members)
                    storage.write_data(data)
                return {"message": "Joined group successfully"}
        
        return JSONResponse(
            status_code=404,
            content={"detail": "Group not found"}
        )
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"detail": f"Failed to join group: {str(e)}"}
        )

@router.post("/groups/{group_id}/leave")
async def leave_group(group_id: str, current_user: str = Depends(get_current_user)):
    try:
        data = storage.read_data()
        for group in data.get("groups", []):
            if group.get("id") == group_id:
                members = _ensure_members_list(group)
                if current_user in members:
                    members = [m for m in members if m != current_user]
                    group["members"] = members
                    group["member_count"] = len(members)
                    storage.write_data(data)
                    
                    # Notify group via WebSocket
                    await group_manager.broadcast_to_group(group_id, {
                        "type": "member_left",
                        "user_id": current_user,
                        "timestamp": datetime.now().isoformat()
                    })
                    
                return {"message": "Left group successfully"}
        
        return JSONResponse(
            status_code=404,
            content={"detail": "Group not found"}
        )
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"detail": f"Failed to leave group: {str(e)}"}
        )
