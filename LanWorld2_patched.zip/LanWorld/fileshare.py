"""
File sharing module
"""

import uuid
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, UploadFile, File, Depends
from fastapi.responses import FileResponse, JSONResponse

from config import CONFIG
from storage import storage
from auth import get_current_user, verify_session_token

router = APIRouter()

class FileManager:
    def __init__(self, upload_dir="lanworld_uploads"):
        self.upload_dir = Path(upload_dir)
        self.upload_dir.mkdir(exist_ok=True)
    
    def save_file(self, file: UploadFile, owner_id: str) -> dict:
        # Generate unique filename
        file_ext = Path(file.filename).suffix if Path(file.filename).suffix else ".bin"
        file_id = str(uuid.uuid4())
        filename = f"{file_id}{file_ext}"
        filepath = self.upload_dir / filename
        
        # Save file
        content = file.file.read()
        with open(filepath, "wb") as f:
            f.write(content)
        
        # Create file record
        file_data = {
            "id": file_id,
            "owner_id": owner_id,
            "filename": file.filename,
            "filepath": str(filepath),
            "size": len(content),
            "visibility": "private",
            "uploaded_at": datetime.now().isoformat()
        }
        
        storage.add_file(file_data)
        return file_data
    
    def get_file(self, file_id: str, user_id: str) -> Path | None:
        files = storage.get_user_files(user_id)
        for file in files:
            if file["id"] == file_id:
                return Path(file["filepath"])
        return None

file_manager = FileManager(CONFIG["upload_dir"])

@router.post("/files/upload")
async def upload_file(file: UploadFile = File(...), current_user: str = Depends(get_current_user)):
    try:
        # Check file size
        content = await file.read()
        if len(content) > CONFIG["max_upload_size"]:
            return JSONResponse(
                status_code=413,
                content={"detail": "File too large"}
            )
        
        # Reset file pointer
        file.file.seek(0)
        
        # Save file
        file_data = file_manager.save_file(file, current_user)
        return file_data
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"detail": f"Upload failed: {str(e)}"}
        )

@router.get("/files")
async def list_files(current_user: str = Depends(get_current_user)):
    try:
        files = storage.get_user_files(current_user)
        return files
    except:
        return []

@router.get("/files/{file_id}")
async def download_file(file_id: str, token: str):
    try:
        user_id = verify_session_token(token)
        if not user_id:
            return JSONResponse(
                status_code=401,
                content={"detail": "Invalid token"}
            )
        
        file_path = file_manager.get_file(file_id, user_id)
        if not file_path or not file_path.exists():
            return JSONResponse(
                status_code=404,
                content={"detail": "File not found"}
            )
        
        return FileResponse(
            path=file_path,
            filename=file_path.name,
            media_type="application/octet-stream"
        )
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"detail": f"Download failed: {str(e)}"}
        )