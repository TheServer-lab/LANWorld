"""
LAN Discovery module
"""

import socket
import json
import threading
import time

from config import CONFIG

class LanDiscovery:
    def __init__(self, port=8888):
        self.port = port
        self.running = False
        self.server_info = {
            "name": "LanWorld",
            "version": "1.0",
            "port": CONFIG["port"],
            "host": socket.gethostbyname(socket.gethostname())
        }
    
    def start(self):
        self.running = True
        thread = threading.Thread(target=self._broadcast_service, daemon=True)
        thread.start()
    
    def stop(self):
        self.running = False
    
    def _broadcast_service(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.settimeout(0.2)
        
        while self.running:
            try:
                message = json.dumps(self.server_info).encode('utf-8')
                sock.sendto(message, ('255.255.255.255', self.port))
            except:
                pass
            
            time.sleep(30)