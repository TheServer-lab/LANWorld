"""
Data models for LanWorld
"""

from pydantic import BaseModel
from typing import Optional, List

class UserCreate(BaseModel):
    username: str
    password: str
    bio: str = ""

class UserLogin(BaseModel):
    username: str
    password: str

class MessageCreate(BaseModel):
    recipient_id: str
    content: str
    type: str = "text"

class PostCreate(BaseModel):
    content: str
    title: Optional[str] = None

class CommentCreate(BaseModel):
    content: str

class FormCreate(BaseModel):
    title: str
    content: str
    category: str = "general"
    tags: Optional[list] = []
    is_poll: bool = False
    poll_options: Optional[list] = []

class FormResponseCreate(BaseModel):
    form_id: str
    response: dict
    is_anonymous: bool = False

class TextDumpCreate(BaseModel):
    title: str
    content: str
    language: str = "text"
    visibility: str = "private"
    expire_hours: Optional[int] = None
    password: Optional[str] = None

class GroupCreate(BaseModel):
    name: str
    description: str = ""
    is_public: bool = True
    members: List[str] = []

class GroupMessageCreate(BaseModel):
    group_id: str
    content: str
    type: str = "text"