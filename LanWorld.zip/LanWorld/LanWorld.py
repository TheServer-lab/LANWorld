#!/usr/bin/env python3
"""
LanWorld - Complete LAN Ecosystem
Main entry point
"""

import socket
import threading
from pathlib import Path

# Third-party imports
from fastapi import FastAPI, WebSocket
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

# Local imports
from config import CONFIG
from discovery import LanDiscovery
import auth
import messenger
import social
import fileshare
import routes

def open_browser():
    import webbrowser
    import time
    time.sleep(2)
    webbrowser.open(f"http://localhost:{CONFIG['port']}")

def main():
    print("""
    ╔══════════════════════════════════════════╗
    ║           LanWorld 1.0                   ║
    ║   Complete LAN Ecosystem                 ║
    ║   100% Local - Zero Cloud                ║
    ╚══════════════════════════════════════════╝
    """)
    
    # Start LAN discovery
    discovery = LanDiscovery(CONFIG["discovery_port"])
    discovery.start()
    print(f"🔍 LAN Discovery started on port {CONFIG['discovery_port']}")
    
    # Create upload directory
    Path(CONFIG["upload_dir"]).mkdir(exist_ok=True, parents=True)
    
    # Create FastAPI app
    app = FastAPI(title="LanWorld", version="1.0")
    
    # CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Include routers
    app.include_router(auth.router, prefix="/api/auth", tags=["Authentication"])
    app.include_router(messenger.router, prefix="/api", tags=["Messenger"])
    app.include_router(social.router, prefix="/api", tags=["Social"])
    app.include_router(fileshare.router, prefix="/api", tags=["Fileshare"])
    app.include_router(routes.router, tags=["Routes"])
    
    # Register WebSocket endpoint directly
    @app.websocket("/api/ws")
    async def websocket_endpoint(websocket: WebSocket, token: str):
        await messenger.websocket_endpoint(websocket, token)
    
    # Open browser
    threading.Thread(target=open_browser, daemon=True).start()
    
    # Get IP addresses
    try:
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        ips = [local_ip]
    except:
        ips = []
    
    print(f"\n🌐 Server starting...")
    print(f"📡 Local URLs:")
    print(f"   http://localhost:{CONFIG['port']}")
    print(f"   http://127.0.0.1:{CONFIG['port']}")
    for ip in ips:
        if ip not in ['127.0.0.1', 'localhost']:
            print(f"   http://{ip}:{CONFIG['port']}")
    
    print(f"\n💡 Other users on your LAN can connect via:")
    print(f"   http://<YOUR-IP>:{CONFIG['port']}")
    print(f"\n🚀 Press Ctrl+C to stop the server\n")
    
    # Start server
    uvicorn.run(
        app, 
        host=CONFIG["host"], 
        port=CONFIG["port"], 
        log_level="info",
        ws_ping_interval=20,
        ws_ping_timeout=20
    )

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n👋 LanWorld server stopped")
        print("Thank you for using LanWorld!")
    except Exception as e:
        print(f"\n❌ Error starting LanWorld: {e}")
        import traceback
        traceback.print_exc()
        print("\nTry installing dependencies with:")
        print("pip install fastapi uvicorn websockets bcrypt python-multipart")
        input("\nPress Enter to exit...")