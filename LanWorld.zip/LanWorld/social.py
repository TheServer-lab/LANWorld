"""
Social feed module
"""

import uuid
from datetime import datetime

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse

from models import PostCreate
from storage import storage
from auth import verify_session_token
from auth import get_current_user

router = APIRouter()

@router.post("/feed/posts")
async def create_post(post: PostCreate, current_user: str = Depends(get_current_user)):
    try:
        post_id = str(uuid.uuid4())
        user = storage.get_user_by_id(current_user)
        
        post_data = {
            "id": post_id,
            "author_id": current_user,
            "author_username": user.get("username", "Unknown") if user else "Unknown",
            "content": post.content,
            "likes": 0,
            "timestamp": datetime.now().isoformat()
        }
        
        storage.add_post(post_data)
        return post_data
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"detail": f"Failed to create post: {str(e)}"}
        )

@router.get("/feed/posts")
async def get_posts(current_user: str = Depends(get_current_user)):
    try:
        posts = storage.get_posts()
        return posts
    except:
        return []

@router.post("/feed/posts/{post_id}/like")
async def like_post(post_id: str, current_user: str = Depends(get_current_user)):
    try:
        # In a real app, you'd update the specific post's like count
        # For simplicity, we'll just return success
        return {"message": "Post liked"}
    except:
        return JSONResponse(
            status_code=500,
            content={"detail": "Failed to like post"}
        )