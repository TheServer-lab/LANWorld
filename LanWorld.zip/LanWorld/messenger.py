"""
Messenger module for real-time chat
"""

import json
import threading
import uuid
from datetime import datetime
from typing import Dict, List, Optional

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends
from fastapi.responses import JSONResponse

from models import MessageCreate
from storage import storage
from auth import verify_session_token, get_current_user

router = APIRouter()

class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}
        self.user_connections: Dict[str, str] = {}
        self.lock = threading.Lock()
    
    async def connect(self, websocket: WebSocket, user_id: str):
        await websocket.accept()
        conn_id = str(uuid.uuid4())
        
        with self.lock:
            self.active_connections[conn_id] = websocket
            self.user_connections[user_id] = conn_id
        
        # Update user as online
        storage.update_user(user_id, {"online": True, "last_seen": datetime.now().isoformat()})
        
        # Broadcast user online status
        await self.broadcast_user_status(user_id, True)
        return conn_id
    
    def disconnect(self, user_id: str):
        with self.lock:
            if user_id in self.user_connections:
                conn_id = self.user_connections[user_id]
                if conn_id in self.active_connections:
                    del self.active_connections[conn_id]
                del self.user_connections[user_id]
        
        # Update user as offline
        storage.update_user(user_id, {"online": False, "last_seen": datetime.now().isoformat()})
    
    async def send_personal_message(self, user_id: str, message: dict):
        with self.lock:
            if user_id in self.user_connections:
                conn_id = self.user_connections[user_id]
                if conn_id in self.active_connections:
                    websocket = self.active_connections[conn_id]
                    try:
                        await websocket.send_json(message)
                    except:
                        pass
    
    async def broadcast(self, message: dict, exclude_user: Optional[str] = None):
        disconnected = []
        with self.lock:
            connections_copy = list(self.user_connections.items())
        
        for user_id, conn_id in connections_copy:
            if exclude_user and user_id == exclude_user:
                continue
            with self.lock:
                websocket = self.active_connections.get(conn_id)
            if websocket:
                try:
                    await websocket.send_json(message)
                except:
                    disconnected.append(user_id)
        
        # Clean up disconnected users
        for user_id in disconnected:
            self.disconnect(user_id)
    
    async def broadcast_user_status(self, user_id: str, online: bool):
        message = {
            "type": "user_status",
            "user_id": user_id,
            "online": online,
            "timestamp": datetime.now().isoformat()
        }
        await self.broadcast(message, exclude_user=user_id)
    
    def is_user_online(self, user_id: str) -> bool:
        with self.lock:
            return user_id in self.user_connections

# Create a global connection manager instance
connection_manager = ConnectionManager()

# WebSocket endpoint - must be a standalone function, not in router
async def websocket_endpoint(websocket: WebSocket, token: str):
    """Handle WebSocket connections for real-time chat"""
    user_id = verify_session_token(token)
    if not user_id:
        await websocket.close(code=1008)
        return
    
    conn_id = await connection_manager.connect(websocket, user_id)
    
    try:
        # Send initial online users list
        online_users = storage.get_online_users()
        await websocket.send_json({
            "type": "online_users",
            "users": online_users
        })
        
        while True:
            try:
                data = await websocket.receive_json()
                
                if data["type"] == "message":
                    # Store message
                    message_id = str(uuid.uuid4())
                    message = {
                        "id": message_id,
                        "sender_id": user_id,
                        "recipient_id": data["recipient_id"],
                        "content": data["content"],
                        "timestamp": datetime.now().isoformat(),
                        "type": "text"
                    }
                    
                    storage.add_message(message)
                    
                    # Forward to recipient if online
                    await connection_manager.send_personal_message(data["recipient_id"], {
                        "type": "message",
                        **message
                    })
                    
                    # Also send back to sender for UI update
                    await websocket.send_json({
                        "type": "message_sent",
                        "message_id": message_id
                    })
                    
                elif data["type"] == "typing":
                    # Forward typing indicator
                    if "recipient_id" in data:
                        await connection_manager.send_personal_message(data["recipient_id"], {
                            "type": "typing",
                            "sender_id": user_id,
                            "is_typing": data.get("is_typing", True)
                        })
                    
            except json.JSONDecodeError:
                pass
            except KeyError as e:
                print(f"KeyError in WebSocket: {e}")
                pass
            except WebSocketDisconnect:
                break
                
    except WebSocketDisconnect:
        pass
    except Exception as e:
        print(f"WebSocket error: {e}")
    finally:
        connection_manager.disconnect(user_id)

# HTTP endpoints
@router.get("/users/online")
async def get_online_users(current_user: str = Depends(get_current_user)):
    try:
        online_users = storage.get_online_users()
        # Remove current user from list
        online_users = [u for u in online_users if u["id"] != current_user]
        return online_users
    except Exception as e:
        print(f"Error getting online users: {e}")
        return []

@router.post("/messages")
async def send_message(message: MessageCreate, current_user: str = Depends(get_current_user)):
    try:
        message_id = str(uuid.uuid4())
        message_data = {
            "id": message_id,
            "sender_id": current_user,
            "recipient_id": message.recipient_id,
            "content": message.content,
            "timestamp": datetime.now().isoformat(),
            "type": message.type
        }
        
        storage.add_message(message_data)
        
        # Try to send via WebSocket if recipient is online
        if connection_manager.is_user_online(message.recipient_id):
            await connection_manager.send_personal_message(message.recipient_id, {
                "type": "message",
                **message_data
            })
        
        return message_data
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"detail": f"Failed to send message: {str(e)}"}
        )

@router.get("/messages/{user_id}")
async def get_messages(user_id: str, current_user: str = Depends(get_current_user)):
    try:
        messages = storage.get_messages(current_user, user_id)
        return messages
    except Exception as e:
        print(f"Error getting messages: {e}")
        return []