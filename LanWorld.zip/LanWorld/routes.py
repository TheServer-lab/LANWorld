"""
General routes and frontend
"""

import socket

from fastapi import APIRouter
from fastapi.responses import HTMLResponse

from config import CONFIG
from storage import storage

router = APIRouter()

HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LanWorld - Local Network Ecosystem</title>
    <style>
        :root {
            --bg-primary: #0f172a;
            --bg-secondary: #1e293b;
            --bg-tertiary: #334155;
            --text-primary: #f8fafc;
            --text-secondary: #cbd5e1;
            --accent: #3b82f6;
            --accent-hover: #2563eb;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            height: 100vh;
            overflow: hidden;
        }
        
        .app {
            display: flex;
            height: 100vh;
            overflow: hidden;
        }
        
        .sidebar {
            width: 300px;
            background: var(--bg-secondary);
            border-right: 1px solid var(--bg-tertiary);
            display: flex;
            flex-direction: column;
            flex-shrink: 0;
        }
        
        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        
        .header {
            padding: 1rem;
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--bg-tertiary);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-shrink: 0;
        }
        
        .view-container {
            flex: 1;
            overflow: hidden;
            position: relative;
        }
        
        .view {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            padding: 1rem;
            overflow-y: auto;
            display: none;
            background: var(--bg-primary);
        }
        
        .view.active {
            display: block;
        }
        
        /* Auth View */
        .auth-container {
            max-width: 400px;
            margin: 2rem auto;
            padding: 2rem;
            background: var(--bg-secondary);
            border-radius: 0.5rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .auth-tabs {
            display: flex;
            margin-bottom: 2rem;
            border-bottom: 1px solid var(--bg-tertiary);
        }
        
        .auth-tab {
            flex: 1;
            padding: 0.75rem;
            text-align: center;
            cursor: pointer;
            border-bottom: 2px solid transparent;
            transition: all 0.2s;
        }
        
        .auth-tab:hover {
            background: var(--bg-tertiary);
        }
        
        .auth-tab.active {
            border-bottom-color: var(--accent);
            color: var(--accent);
        }
        
        .form-group {
            margin-bottom: 1rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: var(--text-secondary);
        }
        
        .form-control {
            width: 100%;
            padding: 0.75rem;
            background: var(--bg-tertiary);
            border: 2px solid var(--bg-tertiary);
            border-radius: 0.375rem;
            color: var(--text-primary);
            font-size: 1rem;
            transition: border-color 0.2s;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
        }
        
        .btn {
            display: inline-block;
            padding: 0.75rem 1.5rem;
            background: var(--accent);
            color: white;
            border: none;
            border-radius: 0.375rem;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.2s;
            text-align: center;
        }
        
        .btn:hover:not(:disabled) {
            background: var(--accent-hover);
            transform: translateY(-1px);
        }
        
        .btn:active:not(:disabled) {
            transform: translateY(0);
        }
        
        .btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        .btn-block {
            width: 100%;
            display: block;
        }
        
        .btn-success {
            background: var(--success);
        }
        
        .btn-success:hover:not(:disabled) {
            background: #0da271;
        }
        
        .btn-danger {
            background: var(--danger);
        }
        
        .btn-danger:hover:not(:disabled) {
            background: #dc2626;
        }
        
        .btn-sm {
            padding: 0.5rem 1rem;
            font-size: 0.875rem;
        }
        
        /* Online Users */
        .online-users {
            padding: 0;
            flex: 1;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
        }
        
        .online-users h3 {
            padding: 1rem;
            margin: 0;
            border-bottom: 1px solid var(--bg-tertiary);
            background: var(--bg-secondary);
            color: var(--text-primary);
            font-size: 16px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .online-users h3::before {
            content: '👥';
        }
        
        #usersList {
            flex: 1;
            overflow-y: auto;
            padding: 1rem;
        }
        
        .user-card {
            display: flex;
            align-items: center;
            padding: 12px;
            background: var(--bg-tertiary);
            border-radius: 10px;
            margin-bottom: 8px;
            cursor: pointer;
            transition: all 0.2s ease;
            border: 2px solid transparent;
            position: relative;
            overflow: hidden;
        }
        
        .user-card:hover {
            background: #4b5563;
            transform: translateY(-2px);
            border-color: var(--accent);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.2);
        }
        
        .user-card.active {
            background: linear-gradient(135deg, var(--accent), #1d4ed8);
            border-color: var(--accent);
            box-shadow: 0 4px 15px rgba(59, 130, 246, 0.3);
        }
        
        .user-card.active::after {
            content: '💬';
            position: absolute;
            right: 12px;
            font-size: 16px;
        }
        
        .user-card:active {
            transform: translateY(0);
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--accent);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 1rem;
            font-weight: bold;
            font-size: 18px;
            flex-shrink: 0;
        }
        
        .user-info {
            flex: 1;
            min-width: 0;
        }
        
        .user-name {
            font-weight: 500;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .user-status {
            font-size: 0.875rem;
            color: var(--text-secondary);
        }
        
        .status-online {
            color: var(--success) !important;
        }
        
        .status-offline {
            color: var(--text-secondary) !important;
        }
        
        /* Chat View */
        .chat-container {
            display: flex;
            flex-direction: column;
            height: 100%;
            background: var(--bg-primary);
        }
        
        .chat-header {
            padding: 16px 20px;
            border-bottom: 2px solid var(--bg-tertiary);
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--bg-secondary);
            border-radius: 12px 12px 0 0;
            flex-shrink: 0;
        }
        
        #chatWith {
            font-size: 18px;
            font-weight: 600;
            color: var(--text-primary);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .chat-messages {
            flex: 1;
            overflow-y: auto;
            padding: 1rem;
            min-height: 0;
        }
        
        .message {
            margin-bottom: 1rem;
            max-width: 75%;
            animation: fadeIn 0.3s ease;
        }
        
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .message.sent {
            margin-left: auto;
            text-align: right;
        }
        
        .message-content {
            display: inline-block;
            padding: 0.75rem 1rem;
            background: var(--bg-tertiary);
            border-radius: 1rem;
            word-break: break-word;
            max-width: 100%;
            line-height: 1.4;
        }
        
        .message.sent .message-content {
            background: var(--accent);
            border-bottom-right-radius: 4px;
        }
        
        .message.received .message-content {
            border-bottom-left-radius: 4px;
        }
        
        .message-time {
            font-size: 0.75rem;
            color: var(--text-secondary);
            margin-top: 0.25rem;
            padding: 0 0.25rem;
        }
        
        .chat-input-container {
            padding: 1rem;
            border-top: 1px solid var(--bg-tertiary);
            background: var(--bg-secondary);
            flex-shrink: 0;
            border-radius: 0 0 12px 12px;
        }
        
        .chat-input-wrapper {
            display: flex;
            flex-direction: column;
        }
        
        .chat-input {
            width: 100%;
            padding: 14px;
            background: var(--bg-tertiary);
            border: 2px solid var(--bg-tertiary);
            border-radius: 12px;
            color: var(--text-primary);
            font-size: 16px;
            resize: none;
            min-height: 70px;
            transition: all 0.2s ease;
            font-family: inherit;
            line-height: 1.5;
        }
        
        .chat-input:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
            background: var(--bg-secondary);
        }
        
        .chat-input:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            background: var(--bg-tertiary);
        }
        
        .chat-input:not(:disabled):hover {
            border-color: #4b5563;
        }
        
        .chat-hint {
            margin-top: 8px;
            font-size: 12px;
            color: var(--text-secondary);
            text-align: center;
            opacity: 0.8;
        }
        
        /* Files View */
        .files-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 1rem;
            margin-top: 1rem;
        }
        
        .file-card {
            background: var(--bg-secondary);
            border-radius: 0.5rem;
            padding: 1rem;
            border: 1px solid var(--bg-tertiary);
            transition: transform 0.2s, border-color 0.2s;
            cursor: pointer;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }
        
        .file-card:hover {
            transform: translateY(-2px);
            border-color: var(--accent);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.1);
        }
        
        .file-icon {
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
        }
        
        .file-name {
            font-weight: 500;
            margin-bottom: 0.25rem;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            width: 100%;
        }
        
        .file-size {
            font-size: 0.875rem;
            color: var(--text-secondary);
        }
        
        /* Feed View */
        .post-card {
            background: var(--bg-secondary);
            border-radius: 0.5rem;
            padding: 1.5rem;
            margin-bottom: 1rem;
            border: 1px solid var(--bg-tertiary);
        }
        
        .post-header {
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .post-content {
            margin-bottom: 1rem;
            line-height: 1.6;
            white-space: pre-wrap;
            word-break: break-word;
        }
        
        .post-actions {
            display: flex;
            gap: 1rem;
            border-top: 1px solid var(--bg-tertiary);
            padding-top: 1rem;
        }
        
        .post-action {
            background: none;
            border: none;
            color: var(--text-secondary);
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem;
            border-radius: 0.375rem;
            transition: all 0.2s;
        }
        
        .post-action:hover {
            color: var(--accent);
            background: var(--bg-tertiary);
        }
        
        /* Utilities */
        .hidden {
            display: none !important;
        }
        
        .text-center {
            text-align: center;
        }
        
        .mt-1 { margin-top: 0.25rem; }
        .mt-2 { margin-top: 0.5rem; }
        .mt-3 { margin-top: 0.75rem; }
        .mt-4 { margin-top: 1rem; }
        .mb-1 { margin-bottom: 0.25rem; }
        .mb-2 { margin-bottom: 0.5rem; }
        .mb-3 { margin-bottom: 0.75rem; }
        .mb-4 { margin-bottom: 1rem; }
        .ml-2 { margin-left: 0.5rem; }
        .p-2 { padding: 0.5rem; }
        .p-3 { padding: 0.75rem; }
        .p-4 { padding: 1rem; }
        
        .notification {
            position: fixed;
            top: 1rem;
            right: 1rem;
            padding: 1rem 1.5rem;
            background: var(--success);
            color: white;
            border-radius: 0.375rem;
            animation: slideIn 0.3s ease;
            z-index: 1000;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            max-width: 300px;
        }
        
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem 1rem;
            color: var(--text-secondary);
        }
        
        .empty-state-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }
        
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid var(--text-secondary);
            border-radius: 50%;
            border-top-color: var(--accent);
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        .debug-button {
            position: fixed;
            bottom: 10px;
            right: 10px;
            z-index: 1000;
            padding: 5px 10px;
            background: #f59e0b;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 12px;
            cursor: pointer;
            opacity: 0.3;
            transition: opacity 0.2s;
        }
        
        .debug-button:hover {
            opacity: 1;
        }
        
        /* Scrollbar styling */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: var(--bg-tertiary);
            border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb {
            background: var(--accent);
            border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: var(--accent-hover);
        }
    </style>
</head>
<body>
    <div id="authView" class="auth-container">
        <div class="auth-tabs">
            <div class="auth-tab active" onclick="showAuthTab('login')">Login</div>
            <div class="auth-tab" onclick="showAuthTab('register')">Register</div>
        </div>
        
        <div id="loginForm">
            <div class="form-group">
                <label for="loginUsername">Username</label>
                <input type="text" id="loginUsername" class="form-control" placeholder="Enter username" autocomplete="username">
            </div>
            <div class="form-group">
                <label for="loginPassword">Password</label>
                <input type="password" id="loginPassword" class="form-control" placeholder="Enter password" autocomplete="current-password">
            </div>
            <button onclick="login()" class="btn btn-block">Sign In</button>
        </div>
        
        <div id="registerForm" class="hidden">
            <div class="form-group">
                <label for="registerUsername">Username</label>
                <input type="text" id="registerUsername" class="form-control" placeholder="Choose username" autocomplete="username">
            </div>
            <div class="form-group">
                <label for="registerPassword">Password</label>
                <input type="password" id="registerPassword" class="form-control" placeholder="Choose password" autocomplete="new-password">
            </div>
            <div class="form-group">
                <label for="registerBio">Bio (Optional)</label>
                <textarea id="registerBio" class="form-control" placeholder="Tell us about yourself" rows="3"></textarea>
            </div>
            <button onclick="register()" class="btn btn-block btn-success">Create Account</button>
        </div>
    </div>
    
    <div id="app" class="app hidden">
        <div class="sidebar">
            <div class="header">
                <h2>🌐 LanWorld</h2>
                <div id="userMenu">
                    <span id="currentUsername" style="font-weight: 500;"></span>
                    <button onclick="logout()" class="btn btn-danger btn-sm ml-2">Logout</button>
                </div>
            </div>
            
            <div class="online-users">
                <h3>👥 Online Users</h3>
                <div id="usersList">
                    <div class="empty-state">
                        <div class="loading"></div>
                        <div class="mt-2">Loading users...</div>
                    </div>
                </div>
            </div>
            
            <div class="p-4">
                <div class="btn-group">
                    <button onclick="showView('chat')" class="btn btn-block mb-2" id="chatBtn">💬 Chat</button>
                    <button onclick="showView('files')" class="btn btn-block mb-2" id="filesBtn">📁 Files</button>
                    <button onclick="showView('feed')" class="btn btn-block mb-2" id="feedBtn">📝 Feed</button>
                    <button onclick="showView('discover')" class="btn btn-block" id="discoverBtn">🔍 Discover</button>
                </div>
            </div>
        </div>
        
        <div class="main-content">
            <div class="view-container">
                <!-- Chat View -->
                <div id="chatView" class="view">
                    <div class="chat-container">
                        <div class="chat-header">
                            <h3 id="chatWith">Select a user from the sidebar to start chatting</h3>
                        </div>
                        <div class="chat-messages" id="chatMessages">
                            <div class="empty-state">
                                <div class="empty-state-icon">💬</div>
                                <h3>No chat selected</h3>
                                <p>Choose a user from the sidebar to start messaging</p>
                            </div>
                        </div>
                        <div class="chat-input-container">
                            <div class="chat-input-wrapper">
                                <textarea 
                                    id="messageInput" 
                                    class="chat-input" 
                                    placeholder="Select a user from the sidebar to start chatting..."
                                    onkeydown="if(event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); sendMessage(); }"
                                    disabled
                                ></textarea>
                                <div class="chat-hint" id="chatHint">Select a user to enable chat</div>
                                <button onclick="sendMessage()" class="btn btn-primary mt-2" disabled id="sendButton">
                                    Send Message
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Files View -->
                <div id="filesView" class="view">
                    <h3>📁 File Sharing</h3>
                    <div class="mb-4">
                        <input type="file" id="fileUpload" class="form-control mb-2">
                        <button onclick="uploadFile()" class="btn">Upload File</button>
                    </div>
                    <div id="filesList" class="files-grid">
                        <div class="empty-state">
                            <div class="empty-state-icon">📁</div>
                            <h3>No files yet</h3>
                            <p>Upload your first file to get started</p>
                        </div>
                    </div>
                </div>
                
                <!-- Feed View -->
                <div id="feedView" class="view">
                    <h3>📝 LAN Feed</h3>
                    <div class="mb-4">
                        <textarea id="postContent" class="form-control mb-2" placeholder="What's happening on the LAN?" rows="3"></textarea>
                        <button onclick="createPost()" class="btn">Post Update</button>
                    </div>
                    <div id="postsList">
                        <div class="empty-state">
                            <div class="empty-state-icon">📝</div>
                            <h3>No posts yet</h3>
                            <p>Be the first to post on the LAN feed!</p>
                        </div>
                    </div>
                </div>
                
                <!-- Discover View -->
                <div id="discoverView" class="view">
                    <h3>🔍 LAN Discovery</h3>
                    <div class="post-card">
                        <h4>Server Information</h4>
                        <p id="serverInfo">Loading server info...</p>
                    </div>
                    <div class="post-card">
                        <h4>Connected Users</h4>
                        <div id="connectedUsers">Loading connected users...</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Global state
        let currentUser = null;
        let currentToken = null;
        let websocket = null;
        let currentChatUser = null;
        let typingTimeout = null;
        
        // Auth functions
        function showAuthTab(tab) {
            document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
            document.getElementById('loginForm').classList.add('hidden');
            document.getElementById('registerForm').classList.add('hidden');
            
            if (tab === 'login') {
                document.querySelector('.auth-tab:nth-child(1)').classList.add('active');
                document.getElementById('loginForm').classList.remove('hidden');
                document.getElementById('loginUsername').focus();
            } else {
                document.querySelector('.auth-tab:nth-child(2)').classList.add('active');
                document.getElementById('registerForm').classList.remove('hidden');
                document.getElementById('registerUsername').focus();
            }
        }
        
        async function login() {
            const username = document.getElementById('loginUsername').value.trim();
            const password = document.getElementById('loginPassword').value;
            
            if (!username || !password) {
                alert('Please enter both username and password');
                return;
            }
            
            try {
                const response = await fetch('/api/auth/login', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({username, password})
                });
                
                const data = await response.json();
                
                if (response.ok) {
                    currentUser = data.user;
                    currentToken = data.token;
                    showMainApp();
                    connectWebSocket();
                    alert('Login successful!');
                } else {
                    alert('Login failed: ' + (data.detail || 'Unknown error'));
                }
            } catch(e) {
                alert('Login error: ' + e.message);
                console.error('Login error:', e);
            }
        }
        
        async function register() {
            const username = document.getElementById('registerUsername').value.trim();
            const password = document.getElementById('registerPassword').value;
            const bio = document.getElementById('registerBio').value.trim() || '';
            
            if (!username || !password) {
                alert('Please enter both username and password');
                return;
            }
            
            if (username.length < 3) {
                alert('Username must be at least 3 characters');
                return;
            }
            
            if (password.length < 6) {
                alert('Password must be at least 6 characters');
                return;
            }
            
            try {
                const response = await fetch('/api/auth/register', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({username, password, bio})
                });
                
                const data = await response.json();
                
                if (response.ok) {
                    alert('Registration successful! Please login.');
                    showAuthTab('login');
                    document.getElementById('loginUsername').value = username;
                    document.getElementById('loginPassword').value = '';
                } else {
                    alert('Registration failed: ' + (data.detail || 'Unknown error'));
                }
            } catch(e) {
                alert('Registration error: ' + e.message);
                console.error('Registration error:', e);
            }
        }
        
        function logout() {
            if (confirm('Are you sure you want to logout?')) {
                if (websocket) {
                    websocket.close();
                }
                currentUser = null;
                currentToken = null;
                currentChatUser = null;
                document.getElementById('app').classList.add('hidden');
                document.getElementById('authView').classList.remove('hidden');
                alert('Logged out successfully');
            }
        }
        
        // Main app functions
        function showMainApp() {
            document.getElementById('authView').classList.add('hidden');
            document.getElementById('app').classList.remove('hidden');
            document.getElementById('currentUsername').textContent = currentUser.username;
            showView('chat');
            loadOnlineUsers();
            loadFiles();
            loadPosts();
        }
        
        function showView(viewName) {
            document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
            document.getElementById(viewName + 'View').classList.add('active');
            
            if (viewName === 'discover') {
                loadDiscoveryInfo();
            }
        }
        
        // WebSocket connection
        function connectWebSocket() {
            const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            const wsUrl = `${protocol}//${window.location.host}/api/ws?token=${currentToken}`;
            
            websocket = new WebSocket(wsUrl);
            
            websocket.onopen = () => {
                console.log('WebSocket connected');
            };
            
            websocket.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    handleWebSocketMessage(data);
                } catch (e) {
                    console.error('Error parsing WebSocket message:', e);
                }
            };
            
            websocket.onclose = () => {
                console.log('WebSocket disconnected');
                setTimeout(() => {
                    if (currentToken) {
                        connectWebSocket();
                    }
                }, 3000);
            };
            
            websocket.onerror = (error) => {
                console.error('WebSocket error:', error);
            };
        }
        
        function handleWebSocketMessage(data) {
            switch(data.type) {
                case 'user_status':
                    updateUserStatus(data.user_id, data.online);
                    break;
                case 'message':
                    if (data.sender_id === currentChatUser) {
                        addMessageToChat(data, false);
                    }
                    break;
                case 'online_users':
                    updateOnlineUsers(data.users);
                    break;
                case 'typing':
                    if (data.sender_id === currentChatUser) {
                        showTypingIndicator(data.sender_id, data.is_typing);
                    }
                    break;
            }
        }
        
        // User management
        async function loadOnlineUsers() {
            try {
                const response = await fetch('/api/users/online', {
                    headers: {'Authorization': `Bearer ${currentToken}`}
                });
                if (response.ok) {
                    const users = await response.json();
                    updateOnlineUsers(users);
                }
            } catch(e) {
                console.error('Error loading users:', e);
            }
        }
        
        function updateOnlineUsers(users) {
            const container = document.getElementById('usersList');
            container.innerHTML = '';
            
            if (users.length === 0) {
                container.innerHTML = '<div class="empty-state"><div class="empty-state-icon">👤</div><h3>No users online</h3><p>Wait for others to join or invite them!</p></div>';
                return;
            }
            
            users.forEach(user => {
                if (user.id === currentUser.id) return;
                
                const userCard = document.createElement('div');
                userCard.className = `user-card ${user.id === currentChatUser ? 'active' : ''}`;
                userCard.onclick = () => startChat(user);
                
                const avatar = document.createElement('div');
                avatar.className = 'user-avatar';
                avatar.textContent = user.username.charAt(0).toUpperCase();
                
                const info = document.createElement('div');
                info.className = 'user-info';
                
                const name = document.createElement('div');
                name.className = 'user-name';
                name.textContent = user.username;
                
                const status = document.createElement('div');
                status.className = `user-status ${user.online ? 'status-online' : 'status-offline'}`;
                status.textContent = user.online ? 'Online' : 'Offline';
                
                info.appendChild(name);
                info.appendChild(status);
                userCard.appendChild(avatar);
                userCard.appendChild(info);
                container.appendChild(userCard);
            });
        }
        
        function updateUserStatus(userId, online) {
            loadOnlineUsers();
        }
        
        // Chat functions
        function startChat(user) {
            currentChatUser = user.id;
            document.getElementById('chatWith').textContent = `Chat with ${user.username}`;
            document.getElementById('messageInput').disabled = false;
            document.getElementById('sendButton').disabled = false;
            loadChatHistory(user.id);
            updateOnlineUsers();
        }
        
        async function loadChatHistory(userId) {
            try {
                const response = await fetch(`/api/messages/${userId}`, {
                    headers: {'Authorization': `Bearer ${currentToken}`}
                });
                
                if (response.ok) {
                    const messages = await response.json();
                    const container = document.getElementById('chatMessages');
                    container.innerHTML = '';
                    
                    messages.forEach(msg => {
                        addMessageToChat(msg, msg.sender_id === currentUser.id);
                    });
                    container.scrollTop = container.scrollHeight;
                }
            } catch(e) {
                console.error('Error loading chat:', e);
            }
        }
        
        function addMessageToChat(message, isSent) {
            const container = document.getElementById('chatMessages');
            const messageDiv = document.createElement('div');
            messageDiv.className = `message ${isSent ? 'sent' : 'received'}`;
            
            const content = document.createElement('div');
            content.className = 'message-content';
            content.textContent = message.content;
            
            const time = document.createElement('div');
            time.className = 'message-time';
            time.textContent = new Date(message.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
            
            messageDiv.appendChild(content);
            messageDiv.appendChild(time);
            container.appendChild(messageDiv);
            container.scrollTop = container.scrollHeight;
        }
        
        async function sendMessage() {
            const input = document.getElementById('messageInput');
            const content = input.value.trim();
            
            if (!content || !currentChatUser) return;
            
            try {
                const response = await fetch('/api/messages', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${currentToken}`
                    },
                    body: JSON.stringify({
                        recipient_id: currentChatUser,
                        content: content,
                        type: 'text'
                    })
                });
                
                if (response.ok) {
                    const message = await response.json();
                    addMessageToChat(message, true);
                    input.value = '';
                    
                    // Send via WebSocket if connected
                    if (websocket && websocket.readyState === WebSocket.OPEN) {
                        websocket.send(JSON.stringify({
                            type: 'message',
                            recipient_id: currentChatUser,
                            content: content
                        }));
                    }
                }
            } catch(e) {
                console.error('Error sending message:', e);
            }
        }
        
        function showTypingIndicator(userId, isTyping) {
            const container = document.getElementById('chatMessages');
            let indicator = document.getElementById('typing-indicator');
            
            if (isTyping && !indicator) {
                indicator = document.createElement('div');
                indicator.id = 'typing-indicator';
                indicator.className = 'message received';
                indicator.innerHTML = '<div class="message-content" style="background: var(--bg-tertiary); color: var(--text-secondary); font-style: italic;">Typing...</div>';
                container.appendChild(indicator);
                container.scrollTop = container.scrollHeight;
            } else if (!isTyping && indicator) {
                indicator.remove();
            }
        }
        
        // File functions
        async function uploadFile() {
            const input = document.getElementById('fileUpload');
            if (!input.files.length) {
                alert('Please select a file first');
                return;
            }
            
            try {
                const formData = new FormData();
                formData.append('file', input.files[0]);
                
                const response = await fetch('/api/files/upload', {
                    method: 'POST',
                    headers: {'Authorization': `Bearer ${currentToken}`},
                    body: formData
                });
                
                const data = await response.json();
                
                if (response.ok) {
                    loadFiles();
                    input.value = '';
                    alert(`File "${data.filename}" uploaded successfully!`);
                } else {
                    alert('Upload failed: ' + (data.detail || 'Unknown error'));
                }
            } catch(e) {
                alert('Upload error: ' + e.message);
                console.error('Upload error:', e);
            }
        }
        
        async function loadFiles() {
            try {
                const response = await fetch('/api/files', {
                    headers: {'Authorization': `Bearer ${currentToken}`}
                });
                
                if (response.ok) {
                    const files = await response.json();
                    const container = document.getElementById('filesList');
                    container.innerHTML = '';
                    
                    if (files.length === 0) {
                        container.innerHTML = '<div class="empty-state"><div class="empty-state-icon">📁</div><h3>No files yet</h3><p>Upload your first file to get started</p></div>';
                        return;
                    }
                    
                    files.forEach(file => {
                        const fileCard = document.createElement('div');
                        fileCard.className = 'file-card';
                        fileCard.onclick = () => downloadFile(file.id);
                        
                        fileCard.innerHTML = `
                            <div class="file-icon">📄</div>
                            <div class="file-name" title="${file.filename}">${file.filename}</div>
                            <div class="file-size">${formatFileSize(file.size)}</div>
                        `;
                        
                        container.appendChild(fileCard);
                    });
                }
            } catch(e) {
                console.error('Error loading files:', e);
            }
        }
        
        async function downloadFile(fileId) {
            window.open(`/api/files/${fileId}?token=${currentToken}`, '_blank');
        }
        
        function formatFileSize(bytes) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }
        
        // Feed functions
        async function createPost() {
            const content = document.getElementById('postContent').value.trim();
            if (!content) {
                alert('Please enter some content for your post');
                return;
            }
            
            try {
                const response = await fetch('/api/feed/posts', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${currentToken}`
                    },
                    body: JSON.stringify({content})
                });
                
                const data = await response.json();
                
                if (response.ok) {
                    document.getElementById('postContent').value = '';
                    loadPosts();
                } else {
                    alert('Failed to create post: ' + (data.detail || 'Unknown error'));
                }
            } catch(e) {
                alert('Error creating post: ' + e.message);
                console.error('Error creating post:', e);
            }
        }
        
        async function loadPosts() {
            try {
                const response = await fetch('/api/feed/posts', {
                    headers: {'Authorization': `Bearer ${currentToken}`}
                });
                
                if (response.ok) {
                    const posts = await response.json();
                    const container = document.getElementById('postsList');
                    container.innerHTML = '';
                    
                    if (posts.length === 0) {
                        container.innerHTML = '<div class="empty-state"><div class="empty-state-icon">📝</div><h3>No posts yet</h3><p>Be the first to post on the LAN feed!</p></div>';
                        return;
                    }
                    
                    posts.forEach(post => {
                        const postCard = document.createElement('div');
                        postCard.className = 'post-card';
                        
                        postCard.innerHTML = `
                            <div class="post-header">
                                <div class="user-avatar" style="margin-right: 1rem;">
                                    ${post.author_username?.charAt(0).toUpperCase() || 'U'}
                                </div>
                                <div>
                                    <div class="user-name">${post.author_username || 'Unknown'}</div>
                                    <div class="user-status">${new Date(post.timestamp).toLocaleString()}</div>
                                </div>
                            </div>
                            <div class="post-content">${escapeHtml(post.content)}</div>
                            <div class="post-actions">
                                <button class="post-action" onclick="likePost('${post.id}')">
                                    👍 ${post.likes || 0}
                                </button>
                            </div>
                        `;
                        
                        container.appendChild(postCard);
                    });
                }
            } catch(e) {
                console.error('Error loading posts:', e);
            }
        }
        
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        async function likePost(postId) {
            try {
                await fetch(`/api/feed/posts/${postId}/like`, {
                    method: 'POST',
                    headers: {'Authorization': `Bearer ${currentToken}`}
                });
                loadPosts();
            } catch(e) {
                console.error('Error liking post:', e);
            }
        }
        
        // Discovery functions
        async function loadDiscoveryInfo() {
            try {
                const response = await fetch('/api/discovery/info');
                if (response.ok) {
                    const info = await response.json();
                    document.getElementById('serverInfo').innerHTML = `
                        <p><strong>Host:</strong> ${info.host}</p>
                        <p><strong>Port:</strong> ${info.port}</p>
                        <p><strong>Users Online:</strong> ${info.users_online}</p>
                        <p><strong>Version:</strong> ${info.version}</p>
                    `;
                }
            } catch(e) {
                console.error('Error loading discovery info:', e);
            }
        }
        
        // Initialize app
        window.onload = () => {
            console.log('LanWorld loaded');
            showAuthTab('login');
        };
    </script>
</body>
</html>"""

@router.get("/", response_class=HTMLResponse)
async def serve_frontend():
    return HTML_TEMPLATE

@router.get("/api/discovery/info")
async def get_discovery_info():
    try:
        online_users = storage.get_online_users()
        return {
            "name": "LanWorld",
            "version": "1.0",
            "host": socket.gethostbyname(socket.gethostname()),
            "port": CONFIG["port"],
            "users_online": len(online_users)
        }
    except:
        return {
            "name": "LanWorld",
            "version": "1.0",
            "host": "localhost",
            "port": CONFIG["port"],
            "users_online": 0
        }