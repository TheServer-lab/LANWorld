"""
Data storage module
"""

import json
import os
import threading
from typing import Dict, List

class DataStorage:
    def __init__(self, data_file="lanworld_data.json", accounts_file="accounts.txt"):
        self.data_file = data_file
        self.accounts_file = accounts_file
        self.lock = threading.Lock()
        self.init_storage()
    
    def init_storage(self):
        with self.lock:
            # Initialize accounts file
            if not os.path.exists(self.accounts_file):
                with open(self.accounts_file, "w") as f:
                    pass  # Create empty file
            
            # Initialize data file
            if not os.path.exists(self.data_file):
                default_data = {
                    "users": {},
                    "messages": [],
                    "files": [],
                    "posts": [],
                    "sessions": {}
                }
                with open(self.data_file, "w") as f:
                    json.dump(default_data, f, indent=2)
    
    def read_accounts(self):
        with self.lock:
            accounts = {}
            if os.path.exists(self.accounts_file):
                with open(self.accounts_file, "r") as f:
                    for line in f:
                        line = line.strip()
                        if line and ":" in line:
                            username, password = line.split(":", 1)
                            accounts[username] = password
            return accounts
    
    def write_account(self, username: str, password: str):
        with self.lock:
            with open(self.accounts_file, "a") as f:
                f.write(f"{username}:{password}\n")
    
    def read_data(self):
        with self.lock:
            with open(self.data_file, "r") as f:
                return json.load(f)
    
    def write_data(self, data):
        with self.lock:
            with open(self.data_file, "w") as f:
                json.dump(data, f, indent=2)
    
    def get_user_by_username(self, username: str):
        data = self.read_data()
        for user_id, user in data["users"].items():
            if user["username"] == username:
                return {"id": user_id, **user}
        return None
    
    def get_user_by_id(self, user_id: str):
        data = self.read_data()
        return data["users"].get(user_id)
    
    def create_user(self, user_id: str, user_data: dict):
        data = self.read_data()
        data["users"][user_id] = user_data
        self.write_data(data)
    
    def update_user(self, user_id: str, updates: dict):
        data = self.read_data()
        if user_id in data["users"]:
            data["users"][user_id].update(updates)
            self.write_data(data)
            return True
        return False
    
    def add_message(self, message: dict):
        data = self.read_data()
        data["messages"].append(message)
        self.write_data(data)
    
    def get_messages(self, user1_id: str, user2_id: str):
        data = self.read_data()
        messages = []
        for msg in data["messages"]:
            if (msg["sender_id"] == user1_id and msg["recipient_id"] == user2_id) or \
               (msg["sender_id"] == user2_id and msg["recipient_id"] == user1_id):
                messages.append(msg)
        return sorted(messages, key=lambda x: x.get("timestamp", ""))
    
    def add_file(self, file_data: dict):
        data = self.read_data()
        data["files"].append(file_data)
        self.write_data(data)
    
    def get_user_files(self, user_id: str):
        data = self.read_data()
        return [f for f in data["files"] if f["owner_id"] == user_id or f.get("visibility") == "public"]
    
    def add_post(self, post: dict):
        data = self.read_data()
        data["posts"].append(post)
        self.write_data(data)
    
    def get_posts(self):
        data = self.read_data()
        return sorted(data["posts"], key=lambda x: x.get("timestamp", ""), reverse=True)[:50]
    
    def add_session(self, token: str, user_id: str, expires_at: str):
        data = self.read_data()
        data["sessions"][token] = {"user_id": user_id, "expires_at": expires_at}
        self.write_data(data)
    
    def get_session(self, token: str):
        data = self.read_data()
        return data["sessions"].get(token)
    
    def delete_session(self, token: str):
        data = self.read_data()
        if token in data["sessions"]:
            del data["sessions"][token]
            self.write_data(data)
    
    def get_online_users(self):
        data = self.read_data()
        online_users = []
        for user_id, user in data["users"].items():
            if user.get("online", False):
                online_users.append({"id": user_id, **user})
        return online_users

# Global storage instance
from config import CONFIG
storage = DataStorage(CONFIG["data_file"], CONFIG["accounts_file"])
