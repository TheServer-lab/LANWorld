"""
Data models for LanWorld
"""

from pydantic import BaseModel
from typing import Optional

class UserCreate(BaseModel):
    username: str
    password: str
    bio: str = ""

class UserLogin(BaseModel):
    username: str
    password: str

class MessageCreate(BaseModel):
    recipient_id: str
    content: str
    type: str = "text"

class PostCreate(BaseModel):
    content: str
