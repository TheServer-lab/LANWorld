"""
Configuration settings for LanWorld
"""

import secrets

CONFIG = {
    "host": "0.0.0.0",
    "port": 8000,
    "discovery_port": 8888,
    "upload_dir": "lanworld_uploads",
    "accounts_file": "accounts.txt",
    "data_file": "lanworld_data.json",
    "secret_key": secrets.token_hex(32),
    "max_upload_size": 100 * 1024 * 1024,  # 100MB
    "admin_password": "admin123",  # Change this!
}
