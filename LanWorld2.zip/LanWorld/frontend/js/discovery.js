// Discovery functionality

async function loadDiscoveryInfo() {
    try {
        const response = await fetch('/api/discovery/info');
        if (response.ok) {
            const info = await response.json();
            document.getElementById('serverInfo').innerHTML = `
                <p><strong>Host:</strong> ${info.host}</p>
                <p><strong>Port:</strong> ${info.port}</p>
                <p><strong>Users Online:</strong> ${info.users_online}</p>
                <p><strong>Version:</strong> ${info.version}</p>
            `;
            
            // Load connected users
            const usersResponse = await fetch('/api/users/online', {
                headers: {'Authorization': `Bearer ${currentToken}`}
            });
            if (usersResponse.ok) {
                const users = await usersResponse.json();
                const connectedUsers = document.getElementById('connectedUsers');
                if (users.length > 0) {
                    connectedUsers.innerHTML = users.map(user => 
                        `<div style="padding: 0.5rem 0; border-bottom: 1px solid var(--bg-tertiary);">
                            <strong>${user.username}</strong> - ${user.online ? '🟢 Online' : '⚫ Offline'}
                        </div>`
                    ).join('');
                } else {
                    connectedUsers.innerHTML = '<p>No users currently connected</p>';
                }
            }
        }
    } catch(e) {
        console.error('Error loading discovery info:', e);
    }
}

// Export to global scope
window.loadDiscoveryInfo = loadDiscoveryInfo;