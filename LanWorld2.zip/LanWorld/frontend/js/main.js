// Main application initialization

function showView(viewName) {
    // Update button states
    document.querySelectorAll('.btn-group .btn').forEach(btn => {
        btn.style.opacity = '0.7';
        btn.style.transform = 'none';
    });
    document.getElementById(viewName + 'Btn').style.opacity = '1';
    document.getElementById(viewName + 'Btn').style.transform = 'translateY(-2px)';
    
    // Show selected view
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    document.getElementById(viewName + 'View').classList.add('active');
    
    // Load data for the view
    switch(viewName) {
        case 'chat':
            loadOnlineUsers();
            break;
        case 'files':
            loadFiles();
            break;
        case 'feed':
            loadPosts();
            break;
        case 'forms':
            loadForms(activeFormCategory);
            break;
        case 'textdump':
            loadTextDumps(activeTextDumpTab);
            break;
        case 'groups':
            loadGroups(activeGroupsTab);
            break;
        case 'discover':
            loadDiscoveryInfo();
            break;
    }
}

// WebSocket connection
function connectWebSocket() {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/api/ws?token=${currentToken}`;
    
    console.log('Connecting WebSocket to:', wsUrl);
    
    websocket = new WebSocket(wsUrl);
    
    websocket.onopen = () => {
        console.log('✅ WebSocket connected');
        showNotification('Connected to chat server', 'success');
    };
    
    websocket.onmessage = (event) => {
        try {
            const data = JSON.parse(event.data);
            handleWebSocketMessage(data);
        } catch (e) {
            console.error('Error parsing WebSocket message:', e, event.data);
        }
    };
    
    websocket.onclose = (event) => {
        console.log('WebSocket disconnected:', event.code, event.reason);
        if (currentToken && event.code !== 1000) {
            console.log('Reconnecting in 3 seconds...');
            showNotification('Connection lost. Reconnecting...', 'warning');
            setTimeout(connectWebSocket, 3000);
        }
    };
    
    websocket.onerror = (error) => {
        console.error('WebSocket error:', error);
        showNotification('Connection error', 'error');
    };
}

function handleWebSocketMessage(data) {
    console.log('WebSocket message:', data);
    switch(data.type) {
        case 'user_status':
            updateUserStatus(data.user_id, data.online);
            break;
        case 'message':
            console.log('New message from:', data.sender_id);
            if (data.sender_id === currentChatUser) {
                addMessageToChat(data, false);
            } else {
                // Show notification for new message from other users
                showNotification(`New message from ${data.sender_id}`, 'info');
            }
            break;
        case 'online_users':
            updateOnlineUsers(data.users);
            break;
        case 'typing':
            if (data.sender_id === currentChatUser) {
                showTypingIndicator(data.sender_id, data.is_typing);
            }
            break;
    }
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    console.log('LanWorld frontend loaded');
    showAuthTab('login');
    
    // Auto-focus username field
    document.getElementById('loginUsername').focus();
    
    // Add Enter key support for login/register
    document.getElementById('loginUsername').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            document.getElementById('loginPassword').focus();
        }
    });
    
    document.getElementById('loginPassword').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            login();
        }
    });
    
    document.getElementById('registerUsername').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            document.getElementById('registerPassword').focus();
        }
    });
    
    document.getElementById('registerPassword').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            document.getElementById('registerBio').focus();
        }
    });
    
    document.getElementById('registerBio').addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            register();
        }
    });
});

// Export to global scope
window.showView = showView;
window.connectWebSocket = connectWebSocket;
window.handleWebSocketMessage = handleWebSocketMessage;