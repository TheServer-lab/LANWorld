#!/usr/bin/env python3
"""
Script to create the frontend directory structure
"""

import os
import shutil
from pathlib import Path

# Define the base directory (where this script is located)
BASE_DIR = Path(__file__).parent
FRONTEND_DIR = BASE_DIR / "frontend"

def create_directory_structure():
    """Create the complete frontend directory structure"""
    
    print("Creating frontend directory structure...")
    
    # Remove existing directory if it exists
    if FRONTEND_DIR.exists():
        print(f"Removing existing frontend directory: {FRONTEND_DIR}")
        shutil.rmtree(FRONTEND_DIR)
    
    # Create directory structure
    dirs = [
        FRONTEND_DIR,
        FRONTEND_DIR / "css",
        FRONTEND_DIR / "js",
        FRONTEND_DIR / "components"
    ]
    
    for dir_path in dirs:
        dir_path.mkdir(parents=True, exist_ok=True)
        print(f"Created directory: {dir_path}")
    
    # Create empty files for the structure
    files = [
        FRONTEND_DIR / "index.html",
        FRONTEND_DIR / "css" / "styles.css",
        FRONTEND_DIR / "js" / "auth.js",
        FRONTEND_DIR / "js" / "chat.js",
        FRONTEND_DIR / "js" / "files.js",
        FRONTEND_DIR / "js" / "feed.js",
        FRONTEND_DIR / "js" / "forms.js",
        FRONTEND_DIR / "js" / "textdump.js",
        FRONTEND_DIR / "js" / "groups.js",
        FRONTEND_DIR / "js" / "discovery.js",
        FRONTEND_DIR / "js" / "utils.js",
        FRONTEND_DIR / "js" / "main.js",
        FRONTEND_DIR / "components" / "modals.html",
        FRONTEND_DIR / "components" / "sidebar.html"
    ]
    
    for file_path in files:
        # Create the file with a basic comment
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(f"/* {file_path.name} - Placeholder file */\n")
        print(f"Created file: {file_path}")
    
    print(f"\n✅ Frontend directory structure created at: {FRONTEND_DIR.absolute()}")
    print("\nNext steps:")
    print("1. Copy the actual content from the previous split files into these files")
    print("2. Run LanWorld.py to start the server")
    print("3. Open http://localhost:8000 in your browser")

if __name__ == "__main__":
    create_directory_structure()
