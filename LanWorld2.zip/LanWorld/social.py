"""
Social feed module with comments and likes
"""

import uuid
from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse

from models import PostCreate, CommentCreate
from storage import storage
from auth import get_current_user

router = APIRouter()

@router.post("/feed/posts")
async def create_post(post: PostCreate, current_user: str = Depends(get_current_user)):
    try:
        post_id = str(uuid.uuid4())
        user = storage.get_user_by_id(current_user)
        
        post_data = {
            "id": post_id,
            "author_id": current_user,
            "author_username": user.get("username", "Unknown") if user else "Unknown",
            "content": post.content,
            "likes": [],
            "like_count": 0,
            "comments_count": 0,
            "timestamp": datetime.now().isoformat()
        }
        
        storage.add_post(post_data)
        return post_data
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"detail": f"Failed to create post: {str(e)}"}
        )

@router.get("/feed/posts")
async def get_posts(current_user: str = Depends(get_current_user)):
    try:
        posts = storage.get_posts()
        # Check if user liked each post
        for post in posts:
            post["liked"] = current_user in post.get("likes", [])
        return posts
    except:
        return []

@router.post("/feed/posts/{post_id}/like")
async def like_post(post_id: str, current_user: str = Depends(get_current_user)):
    try:
        data = storage.read_data()
        for post in data["posts"]:
            if post["id"] == post_id:
                if current_user in post.get("likes", []):
                    # Unlike
                    post["likes"] = [uid for uid in post.get("likes", []) if uid != current_user]
                else:
                    # Like
                    if "likes" not in post:
                        post["likes"] = []
                    post["likes"].append(current_user)
                post["like_count"] = len(post.get("likes", []))
                storage.write_data(data)
                return {"message": "Success", "liked": current_user in post.get("likes", [])}
        return JSONResponse(
            status_code=404,
            content={"detail": "Post not found"}
        )
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"detail": f"Failed to like post: {str(e)}"}
        )

@router.post("/feed/posts/{post_id}/comments")
async def add_comment(post_id: str, comment: CommentCreate, current_user: str = Depends(get_current_user)):
    try:
        comment_id = str(uuid.uuid4())
        user = storage.get_user_by_id(current_user)
        
        comment_data = {
            "id": comment_id,
            "post_id": post_id,
            "author_id": current_user,
            "author_username": user.get("username", "Unknown") if user else "Unknown",
            "content": comment.content,
            "timestamp": datetime.now().isoformat()
        }
        
        storage.add_comment(comment_data)
        
        # Update post comment count
        data = storage.read_data()
        for post in data["posts"]:
            if post["id"] == post_id:
                post["comments_count"] = post.get("comments_count", 0) + 1
                storage.write_data(data)
                break
        
        return comment_data
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"detail": f"Failed to add comment: {str(e)}"}
        )

@router.get("/feed/posts/{post_id}/comments")
async def get_comments(post_id: str, current_user: str = Depends(get_current_user)):
    try:
        comments = storage.get_comments(post_id)
        return comments
    except:
        return []

@router.get("/feed/posts/user/{user_id}")
async def get_user_posts(user_id: str, current_user: str = Depends(get_current_user)):
    try:
        posts = storage.get_user_posts(user_id)
        for post in posts:
            post["liked"] = current_user in post.get("likes", [])
        return posts
    except:
        return []