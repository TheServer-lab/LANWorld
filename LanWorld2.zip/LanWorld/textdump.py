"""
Text Dump module for sharing code/text snippets
"""

import uuid
from datetime import datetime, timedelta
from typing import Optional

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from storage import storage
from auth import get_current_user

router = APIRouter()

class TextDumpCreate(BaseModel):
    title: str
    content: str
    language: str = "text"
    visibility: str = "private"  # private, public, unlisted
    expire_hours: Optional[int] = None
    password: Optional[str] = None

@router.post("/textdump")
async def create_text_dump(dump: TextDumpCreate, current_user: str = Depends(get_current_user)):
    try:
        dump_id = str(uuid.uuid4())
        
        # Calculate expiration
        expires_at = None
        if dump.expire_hours:
            expires_at = (datetime.now() + timedelta(hours=dump.expire_hours)).isoformat()
        
        dump_data = {
            "id": dump_id,
            "title": dump.title,
            "content": dump.content,
            "language": dump.language,
            "visibility": dump.visibility,
            "owner_id": current_user,
            "views": 0,
            "created_at": datetime.now().isoformat(),
            "expires_at": expires_at,
            "has_password": bool(dump.password),
            "password_hash": hash_password(dump.password) if dump.password else None
        }
        
        storage.add_text_dump(dump_data)
        return {"id": dump_id, "message": "Text dump created"}
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"detail": f"Failed to create text dump: {str(e)}"}
        )

@router.get("/textdump")
async def list_text_dumps(language: Optional[str] = None, current_user: str = Depends(get_current_user)):
    try:
        dumps = storage.get_text_dumps(current_user)
        
        # Filter expired dumps
        now = datetime.now()
        valid_dumps = []
        for dump in dumps:
            if dump.get("expires_at"):
                expires = datetime.fromisoformat(dump["expires_at"])
                if expires < now:
                    continue
            if language and dump.get("language") != language:
                continue
            valid_dumps.append(dump)
        
        return valid_dumps
    except:
        return []

@router.get("/textdump/public")
async def get_public_dumps(language: Optional[str] = None):
    try:
        data = storage.read_data()
        dumps = data.get("text_dumps", [])
        
        # Get public dumps
        public_dumps = [d for d in dumps if d.get("visibility") == "public"]
        
        # Filter expired
        now = datetime.now()
        valid_dumps = []
        for dump in public_dumps:
            if dump.get("expires_at"):
                expires = datetime.fromisoformat(dump["expires_at"])
                if expires < now:
                    continue
            if language and dump.get("language") != language:
                continue
            # Remove sensitive data
            dump_copy = dump.copy()
            if "password_hash" in dump_copy:
                del dump_copy["password_hash"]
            valid_dumps.append(dump_copy)
        
        return valid_dumps
    except:
        return []

@router.get("/textdump/{dump_id}")
async def get_text_dump(dump_id: str, password: Optional[str] = None):
    try:
        dump = storage.get_text_dump(dump_id)
        if not dump:
            return JSONResponse(
                status_code=404,
                content={"detail": "Text dump not found"}
            )
        
        # Check expiration
        if dump.get("expires_at"):
            expires = datetime.fromisoformat(dump["expires_at"])
            if expires < datetime.now():
                return JSONResponse(
                    status_code=410,
                    content={"detail": "Text dump has expired"}
                )
        
        # Check password
        if dump.get("has_password"):
            if not password or not verify_password(password, dump.get("password_hash")):
                return JSONResponse(
                    status_code=403,
                    content={"detail": "Password required"}
                )
        
        # Check visibility
        visibility = dump.get("visibility", "private")
        if visibility == "private":
            return JSONResponse(
                status_code=403,
                content={"detail": "Private text dump"}
            )
        
        # Increment view count
        data = storage.read_data()
        for d in data["text_dumps"]:
            if d["id"] == dump_id:
                d["views"] = d.get("views", 0) + 1
                storage.write_data(data)
                break
        
        # Remove sensitive data
        response = dump.copy()
        if "password_hash" in response:
            del response["password_hash"]
        
        return response
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"detail": f"Failed to get text dump: {str(e)}"}
        )

def hash_password(password: str) -> str:
    import hashlib
    return hashlib.sha256(password.encode()).hexdigest()

def verify_password(password: str, hashed_password: str) -> bool:
    return hash_password(password) == hashed_password