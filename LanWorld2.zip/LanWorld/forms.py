"""
Forms module for Reddit-style posts with categories
"""

import uuid
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from storage import storage
from auth import get_current_user

router = APIRouter()

class FormCreate(BaseModel):
    title: str
    content: str
    category: str = "general"
    tags: Optional[list] = []
    is_poll: bool = False
    poll_options: Optional[list] = []

class FormResponseCreate(BaseModel):
    form_id: str
    response: dict
    is_anonymous: bool = False

@router.post("/forms")
async def create_form(form: FormCreate, current_user: str = Depends(get_current_user)):
    try:
        form_id = str(uuid.uuid4())
        user = storage.get_user_by_id(current_user)
        
        form_data = {
            "id": form_id,
            "title": form.title,
            "content": form.content,
            "category": form.category,
            "tags": form.tags or [],
            "is_poll": form.is_poll,
            "poll_options": form.poll_options or [],
            "author_id": current_user,
            "author_username": user.get("username", "Unknown") if user else "Unknown",
            "upvotes": 0,
            "downvotes": 0,
            "score": 0,
            "responses_count": 0,
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat()
        }
        
        storage.add_form(form_data)
        return form_data
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"detail": f"Failed to create form: {str(e)}"}
        )

@router.get("/forms")
async def get_forms(category: Optional[str] = None, current_user: str = Depends(get_current_user)):
    try:
        forms = storage.get_forms()
        if category:
            forms = [f for f in forms if f["category"] == category]
        
        # Calculate scores
        for form in forms:
            form["score"] = form.get("upvotes", 0) - form.get("downvotes", 0)
        
        return forms
    except:
        return []

@router.get("/forms/categories")
async def get_categories(current_user: str = Depends(get_current_user)):
    try:
        forms = storage.get_forms()
        categories = set()
        for form in forms:
            categories.add(form.get("category", "general"))
        return list(categories)
    except:
        return ["general", "discussion", "question", "announcement"]

@router.post("/forms/{form_id}/vote")
async def vote_form(form_id: str, vote_type: str, current_user: str = Depends(get_current_user)):
    try:
        data = storage.read_data()
        for form in data["forms"]:
            if form["id"] == form_id:
                # Remove existing votes from this user
                if "upvoters" not in form:
                    form["upvoters"] = []
                if "downvoters" not in form:
                    form["downvoters"] = []
                
                form["upvoters"] = [uid for uid in form.get("upvoters", []) if uid != current_user]
                form["downvoters"] = [uid for uid in form.get("downvoters", []) if uid != current_user]
                
                # Add new vote
                if vote_type == "up":
                    form["upvoters"].append(current_user)
                elif vote_type == "down":
                    form["downvoters"].append(current_user)
                
                form["upvotes"] = len(form.get("upvoters", []))
                form["downvotes"] = len(form.get("downvoters", []))
                form["score"] = form["upvotes"] - form["downvotes"]
                form["updated_at"] = datetime.now().isoformat()
                
                storage.write_data(data)
                return {
                    "message": "Vote recorded",
                    "upvotes": form["upvotes"],
                    "downvotes": form["downvotes"],
                    "score": form["score"]
                }
        
        return JSONResponse(
            status_code=404,
            content={"detail": "Form not found"}
        )
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"detail": f"Failed to vote: {str(e)}"}
        )

@router.post("/forms/{form_id}/responses")
async def submit_response(form_id: str, response: FormResponseCreate, current_user: str = Depends(get_current_user)):
    try:
        response_id = str(uuid.uuid4())
        user = storage.get_user_by_id(current_user)
        
        response_data = {
            "id": response_id,
            "form_id": form_id,
            "respondent_id": None if response.is_anonymous else current_user,
            "respondent_username": None if response.is_anonymous else user.get("username", "Anonymous"),
            "response": response.response,
            "is_anonymous": response.is_anonymous,
            "timestamp": datetime.now().isoformat()
        }
        
        storage.add_form_response(response_data)
        
        # Update form response count
        data = storage.read_data()
        for form in data["forms"]:
            if form["id"] == form_id:
                form["responses_count"] = form.get("responses_count", 0) + 1
                form["updated_at"] = datetime.now().isoformat()
                storage.write_data(data)
                break
        
        return response_data
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"detail": f"Failed to submit response: {str(e)}"}
        )

@router.get("/forms/{form_id}/responses")
async def get_responses(form_id: str, current_user: str = Depends(get_current_user)):
    try:
        responses = storage.get_form_responses(form_id)
        return responses
    except:
        return []